"""
Lambda: ProcessParallelResultsFunction

Consolidates results from parallel processing branches (metadata and download).
Updates DynamoDB with consolidated results.

Input:
{
    "dialogGroupId": "DG-2024-001234",
    "callId": "CALL-5678-ABCD",
    "exportJobId": "EXP-JOB-9999",
    "metadataResult": {
        "metadata": {...},
        "retrievedAt": "..."
    },
    "downloadResult": {
        "status": "SUCCESS",
        "downloadLocation": "s3://bucket/path/file.wav",
        "fileSize": 15728640,
        "checksum": "abc123..."
    },
    "tableName": "ReconciliationTable"
}

Output:
{
    "metadata": {...},
    "downloadLocation": "s3://bucket/path/file.wav",
    "processingDurationMs": 12500,
    "status": "SUCCESS"
}
"""

import os
import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import boto3
from botocore.exceptions import ClientError

# Add shared utilities to path
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'shared'))

from utils import (
    lambda_handler_decorator,
    get_current_timestamp,
    AWSClients
)

logger = logging.getLogger()
logger.setLevel(os.environ.get('LOG_LEVEL', 'INFO'))

TABLE_NAME = os.environ.get('TABLE_NAME')


@lambda_handler_decorator
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Consolidates results from parallel processing branches.
    
    Args:
        event: Input containing metadataResult and downloadResult
        context: Lambda context
        
    Returns:
        Consolidated results with metadata and download location
    """
    # Extract input parameters
    dialog_group_id = event['dialogGroupId']
    call_id = event['callId']
    export_job_id = event['exportJobId']
    metadata_result = event['metadataResult']
    download_result = event['downloadResult']
    table_name = event.get('tableName', TABLE_NAME)
    
    logger.info(json.dumps({
        'message': 'Processing parallel results',
        'dialogGroupId': dialog_group_id,
        'exportJobId': export_job_id,
        'downloadStatus': download_result.get('status')
    }))
    
    # Extract metadata
    metadata = metadata_result.get('metadata', {})
    metadata_retrieved_at = metadata_result.get('retrievedAt')
    
    # Extract download results
    download_status = download_result.get('status', 'UNKNOWN')
    download_location = download_result.get('downloadLocation') or download_result.get('filePath')
    download_file_size = download_result.get('fileSize')
    download_checksum = download_result.get('checksum')
    download_completed_at = download_result.get('completedAt')
    
    # Calculate processing duration if we have timing info
    processing_duration_ms = calculate_processing_duration(
        metadata.get('startTime'),
        download_completed_at
    )
    
    # Consolidate results
    consolidated = {
        'dialogGroupId': dialog_group_id,
        'callId': call_id,
        'exportJobId': export_job_id,
        'metadata': metadata,
        'metadataRetrievedAt': metadata_retrieved_at,
        'downloadStatus': download_status,
        'downloadLocation': download_location,
        'downloadFileSize': download_file_size,
        'downloadChecksum': download_checksum,
        'downloadCompletedAt': download_completed_at,
        'processingDurationMs': processing_duration_ms,
        'consolidatedAt': get_current_timestamp()
    }
    
    # Determine overall status
    if download_status == 'SUCCESS' and metadata:
        consolidated['status'] = 'SUCCESS'
    elif download_status == 'SUCCESS' and not metadata:
        consolidated['status'] = 'PARTIAL_SUCCESS_NO_METADATA'
        logger.warning(json.dumps({
            'message': 'Download succeeded but metadata is empty',
            'dialogGroupId': dialog_group_id,
            'exportJobId': export_job_id
        }))
    else:
        consolidated['status'] = 'FAILED'
        consolidated['failureReason'] = download_result.get('error', 'Unknown download error')
    
    # Update DynamoDB with consolidated results
    try:
        update_dynamo_with_results(
            table_name=table_name,
            dialog_group_id=dialog_group_id,
            consolidated=consolidated
        )
    except Exception as e:
        logger.error(json.dumps({
            'message': 'Failed to update DynamoDB with consolidated results',
            'error': str(e),
            'dialogGroupId': dialog_group_id
        }))
        # Don't fail the Lambda - we can still return the consolidated results
    
    # Clean up task token record
    try:
        cleanup_task_token_record(
            table_name=table_name,
            download_result=download_result
        )
    except Exception as e:
        logger.warning(json.dumps({
            'message': 'Failed to cleanup task token record',
            'error': str(e)
        }))
    
    logger.info(json.dumps({
        'message': 'Parallel results consolidated successfully',
        'dialogGroupId': dialog_group_id,
        'exportJobId': export_job_id,
        'status': consolidated['status'],
        'downloadLocation': download_location
    }))
    
    return consolidated


def calculate_processing_duration(start_time: Optional[str], end_time: Optional[str]) -> Optional[int]:
    """
    Calculates processing duration in milliseconds.
    
    Args:
        start_time: ISO 8601 start timestamp
        end_time: ISO 8601 end timestamp
        
    Returns:
        Duration in milliseconds or None if calculation not possible
    """
    if not start_time or not end_time:
        return None
    
    try:
        start = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
        end = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
        duration = end - start
        return int(duration.total_seconds() * 1000)
    except (ValueError, TypeError) as e:
        logger.warning(f'Failed to calculate processing duration: {str(e)}')
        return None


def update_dynamo_with_results(
    table_name: str,
    dialog_group_id: str,
    consolidated: Dict[str, Any]
) -> None:
    """
    Updates DynamoDB with consolidated results.
    
    Args:
        table_name: DynamoDB table name
        dialog_group_id: Dialog group identifier
        consolidated: Consolidated results dictionary
    """
    table = AWSClients.dynamodb().Table(table_name)
    
    table.update_item(
        Key={
            'PK': f'CALL#{dialog_group_id}',
            'SK': 'RECONCILIATION'
        },
        UpdateExpression='''
            SET downloadStatus = :dlStatus,
                downloadLocation = :dlLocation,
                downloadFileSize = :dlSize,
                downloadChecksum = :dlChecksum,
                downloadCompletedAt = :dlCompletedAt,
                audioMetadata = :metadata,
                metadataRetrievedAt = :metaRetrievedAt,
                processingDurationMs = :procDuration,
                parallelProcessingCompletedAt = :completedAt,
                lastUpdated = :now
        ''',
        ExpressionAttributeValues={
            ':dlStatus': consolidated.get('downloadStatus'),
            ':dlLocation': consolidated.get('downloadLocation'),
            ':dlSize': consolidated.get('downloadFileSize'),
            ':dlChecksum': consolidated.get('downloadChecksum'),
            ':dlCompletedAt': consolidated.get('downloadCompletedAt'),
            ':metadata': json.dumps(consolidated.get('metadata', {})),
            ':metaRetrievedAt': consolidated.get('metadataRetrievedAt'),
            ':procDuration': consolidated.get('processingDurationMs'),
            ':completedAt': consolidated.get('consolidatedAt'),
            ':now': get_current_timestamp()
        }
    )


def cleanup_task_token_record(
    table_name: str,
    download_result: Dict[str, Any]
) -> None:
    """
    Cleans up the task token record after successful processing.
    
    Args:
        table_name: DynamoDB table name
        download_result: Download result containing downloadTaskId
    """
    download_task_id = download_result.get('downloadTaskId')
    if not download_task_id:
        return
    
    table = AWSClients.dynamodb().Table(table_name)
    
    try:
        # Update the task token record status instead of deleting
        # This maintains audit trail
        table.update_item(
            Key={
                'PK': f'TASK#{download_task_id}',
                'SK': 'TOKEN'
            },
            UpdateExpression='SET #status = :status, completedAt = :completedAt',
            ExpressionAttributeNames={
                '#status': 'status'
            },
            ExpressionAttributeValues={
                ':status': 'COMPLETED',
                ':completedAt': get_current_timestamp()
            }
        )
    except ClientError as e:
        # Record might not exist or already cleaned up
        if e.response['Error']['Code'] != 'ConditionalCheckFailedException':
            raise
