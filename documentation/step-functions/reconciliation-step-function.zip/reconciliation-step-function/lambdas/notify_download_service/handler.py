"""
Lambda: NotifyDownloadServiceFunction

Sends download task to Fargate service via SQS and stores task token for callback.
This Lambda is invoked with waitForTaskToken integration.

The Step Function will pause at this state until:
1. Fargate calls SendTaskSuccess with the task token (success)
2. Fargate calls SendTaskFailure with the task token (failure)
3. HeartbeatTimeout occurs (Fargate stopped sending heartbeats)
4. Timeout occurs (exceeded maximum download time)

Input:
{
    "taskToken": "AAAA...long-token...ZZZZ",
    "exportJobId": "EXP-JOB-9999",
    "dialogGroupId": "DG-2024-001234",
    "callId": "CALL-5678-ABCD",
    "downloadUrl": "https://ocp-export.example.com/files/EXP-JOB-9999.zip",
    "config": {
        "timeoutSeconds": 18000,
        "heartbeatSeconds": 600
    }
}

Output (Lambda returns immediately - SF waits for callback):
{
    "notificationSent": true,
    "sqsMessageId": "MSG-12345",
    "queueUrl": "https://sqs...",
    "taskTokenStored": true
}
"""

import os
import json
import logging
import uuid
from typing import Any, Dict

import boto3
from botocore.exceptions import ClientError

# Add shared utilities to path
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'shared'))

from utils import (
    lambda_handler_decorator,
    get_current_timestamp,
    get_ttl_timestamp,
    AWSClients,
    DownloadServiceError
)

logger = logging.getLogger()
logger.setLevel(os.environ.get('LOG_LEVEL', 'INFO'))

# Environment variables
DOWNLOAD_SERVICE_QUEUE_URL = os.environ.get('DOWNLOAD_SERVICE_QUEUE_URL')
TABLE_NAME = os.environ.get('TABLE_NAME')


@lambda_handler_decorator
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Sends download task to Fargate service and stores task token.
    
    Args:
        event: Input containing taskToken, exportJobId, dialogGroupId, downloadUrl, config
        context: Lambda context
        
    Returns:
        Confirmation of notification sent
        
    Raises:
        DownloadServiceError: If SQS send or DynamoDB update fails
    """
    # Extract input parameters
    task_token = event['taskToken']
    export_job_id = event['exportJobId']
    dialog_group_id = event['dialogGroupId']
    call_id = event['callId']
    download_url = event['downloadUrl']
    config = event.get('config', {})
    
    timeout_seconds = config.get('timeoutSeconds', 18000)
    heartbeat_seconds = config.get('heartbeatSeconds', 600)
    
    # Generate unique download task ID
    download_task_id = f"DT-{uuid.uuid4().hex[:12].upper()}"
    
    logger.info(json.dumps({
        'message': 'Notifying download service',
        'downloadTaskId': download_task_id,
        'exportJobId': export_job_id,
        'dialogGroupId': dialog_group_id,
        'timeoutSeconds': timeout_seconds,
        'heartbeatSeconds': heartbeat_seconds
    }))
    
    # Step 1: Store task token in DynamoDB for recovery scenarios
    task_token_stored = store_task_token(
        dialog_group_id=dialog_group_id,
        export_job_id=export_job_id,
        task_token=task_token,
        download_task_id=download_task_id,
        timeout_seconds=timeout_seconds,
        heartbeat_seconds=heartbeat_seconds
    )
    
    # Step 2: Send message to download service queue
    try:
        sqs_message = {
            'downloadTaskId': download_task_id,
            'taskToken': task_token,
            'exportJobId': export_job_id,
            'dialogGroupId': dialog_group_id,
            'callId': call_id,
            'downloadUrl': download_url,
            'config': {
                'timeoutSeconds': timeout_seconds,
                'heartbeatSeconds': heartbeat_seconds,
                'heartbeatIntervalSeconds': min(heartbeat_seconds - 60, 300)  # Send heartbeat before timeout
            },
            'sentAt': get_current_timestamp()
        }
        
        response = AWSClients.sqs().send_message(
            QueueUrl=DOWNLOAD_SERVICE_QUEUE_URL,
            MessageBody=json.dumps(sqs_message),
            MessageAttributes={
                'DialogGroupId': {
                    'DataType': 'String',
                    'StringValue': dialog_group_id
                },
                'ExportJobId': {
                    'DataType': 'String',
                    'StringValue': export_job_id
                },
                'DownloadTaskId': {
                    'DataType': 'String',
                    'StringValue': download_task_id
                }
            },
            MessageGroupId=dialog_group_id if '.fifo' in DOWNLOAD_SERVICE_QUEUE_URL else None,
            MessageDeduplicationId=download_task_id if '.fifo' in DOWNLOAD_SERVICE_QUEUE_URL else None
        )
        
        sqs_message_id = response['MessageId']
        
        logger.info(json.dumps({
            'message': 'Download task sent to SQS',
            'sqsMessageId': sqs_message_id,
            'downloadTaskId': download_task_id,
            'exportJobId': export_job_id,
            'dialogGroupId': dialog_group_id
        }))
        
    except ClientError as e:
        logger.error(json.dumps({
            'message': 'Failed to send download task to SQS',
            'error': str(e),
            'downloadTaskId': download_task_id,
            'exportJobId': export_job_id
        }))
        raise DownloadServiceError(f'Failed to send download task: {str(e)}')
    
    # Step 3: Update DynamoDB with download initiated status
    try:
        table = AWSClients.dynamodb().Table(TABLE_NAME)
        
        table.update_item(
            Key={
                'PK': f'CALL#{dialog_group_id}',
                'SK': 'RECONCILIATION'
            },
            UpdateExpression='''
                SET downloadTaskId = :taskId,
                    downloadStatus = :status,
                    downloadInitiatedAt = :initiatedAt,
                    downloadSqsMessageId = :msgId,
                    lastUpdated = :now
            ''',
            ExpressionAttributeValues={
                ':taskId': download_task_id,
                ':status': 'INITIATED',
                ':initiatedAt': get_current_timestamp(),
                ':msgId': sqs_message_id,
                ':now': get_current_timestamp()
            }
        )
        
    except ClientError as e:
        # Log but don't fail - the download task was sent
        logger.warning(json.dumps({
            'message': 'Failed to update DynamoDB with download status',
            'error': str(e),
            'downloadTaskId': download_task_id
        }))
    
    # Return immediately - Step Function will wait for callback
    return {
        'notificationSent': True,
        'sqsMessageId': sqs_message_id,
        'queueUrl': DOWNLOAD_SERVICE_QUEUE_URL,
        'downloadTaskId': download_task_id,
        'taskTokenStored': task_token_stored,
        'sentAt': get_current_timestamp()
    }


def store_task_token(
    dialog_group_id: str,
    export_job_id: str,
    task_token: str,
    download_task_id: str,
    timeout_seconds: int,
    heartbeat_seconds: int
) -> bool:
    """
    Stores task token in DynamoDB for recovery scenarios.
    
    If the Orchestrator or system crashes, we can retrieve the task token
    and either send callbacks or allow proper timeout handling.
    
    Args:
        dialog_group_id: Dialog group identifier
        export_job_id: Export job identifier
        task_token: Step Functions task token
        download_task_id: Unique download task identifier
        timeout_seconds: Download timeout configuration
        heartbeat_seconds: Heartbeat timeout configuration
        
    Returns:
        True if stored successfully, False otherwise
    """
    try:
        table = AWSClients.dynamodb().Table(TABLE_NAME)
        current_time = get_current_timestamp()
        
        # Store task token with separate record for easy querying
        table.put_item(
            Item={
                'PK': f'TASK#{download_task_id}',
                'SK': 'TOKEN',
                'taskToken': task_token,
                'dialogGroupId': dialog_group_id,
                'exportJobId': export_job_id,
                'downloadTaskId': download_task_id,
                'status': 'PENDING',
                'createdAt': current_time,
                'lastHeartbeat': current_time,
                'timeoutSeconds': timeout_seconds,
                'heartbeatSeconds': heartbeat_seconds,
                'TTL': get_ttl_timestamp(days=1)  # Auto-cleanup after 24 hours
            }
        )
        
        logger.info(json.dumps({
            'message': 'Task token stored successfully',
            'downloadTaskId': download_task_id,
            'dialogGroupId': dialog_group_id
        }))
        
        return True
        
    except ClientError as e:
        logger.error(json.dumps({
            'message': 'Failed to store task token',
            'error': str(e),
            'downloadTaskId': download_task_id,
            'dialogGroupId': dialog_group_id
        }))
        return False
