"""
Lambda: CreateExportJobFunction

Creates export job in OCP Export API and updates DynamoDB with initial status.
This is the first step in the reconciliation process.

Input:
{
    "dialogGroupId": "DG-2024-001234",
    "callId": "CALL-5678-ABCD",
    "executionArn": "arn:aws:states:...",
    "requestedAt": "2024-01-15T10:35:00Z",
    "tableName": "ReconciliationTable"
}

Output:
{
    "exportJobId": "EXP-JOB-9999",
    "status": "CREATED",
    "estimatedCompletionTime": "2024-01-15T10:45:00Z",
    "dynamoUpdateSuccess": true
}
"""

import os
import json
import logging
from typing import Any, Dict

import boto3
from botocore.exceptions import ClientError

# Add shared utilities to path
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'shared'))

from utils import (
    lambda_handler_decorator,
    get_current_timestamp,
    get_ttl_timestamp,
    get_ocp_client,
    AWSClients,
    OCPAPIError,
    DynamoDBError
)

logger = logging.getLogger()
logger.setLevel(os.environ.get('LOG_LEVEL', 'INFO'))


@lambda_handler_decorator
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Creates export job in OCP and updates DynamoDB.
    
    Args:
        event: Input containing dialogGroupId, callId, executionArn, requestedAt, tableName
        context: Lambda context
        
    Returns:
        Export job details including exportJobId and status
        
    Raises:
        OCPAPIError: If OCP API call fails
        DynamoDBError: If DynamoDB update fails (logged but not raised)
    """
    # Extract input parameters
    dialog_group_id = event['dialogGroupId']
    call_id = event['callId']
    execution_arn = event['executionArn']
    requested_at = event['requestedAt']
    table_name = event['tableName']
    
    logger.info(json.dumps({
        'message': 'Creating export job',
        'dialogGroupId': dialog_group_id,
        'callId': call_id
    }))
    
    # Step 1: Create Export Job in OCP
    ocp_client = get_ocp_client()
    
    try:
        export_response = ocp_client.create_export_job(
            dialog_group_id=dialog_group_id,
            call_id=call_id
        )
        
        export_job_id = export_response.get('exportJobId')
        estimated_completion = export_response.get('estimatedCompletionTime')
        
        if not export_job_id:
            raise OCPAPIError('OCP API did not return exportJobId')
        
        logger.info(json.dumps({
            'message': 'Export job created successfully',
            'exportJobId': export_job_id,
            'dialogGroupId': dialog_group_id
        }))
        
    except Exception as e:
        logger.error(json.dumps({
            'message': 'Failed to create export job',
            'error': str(e),
            'dialogGroupId': dialog_group_id,
            'callId': call_id
        }))
        raise
    
    # Step 2: Update DynamoDB with initial status
    dynamo_update_success = False
    
    try:
        table = AWSClients.dynamodb().Table(table_name)
        current_time = get_current_timestamp()
        ttl = get_ttl_timestamp(days=30)
        
        table.update_item(
            Key={
                'PK': f'CALL#{dialog_group_id}',
                'SK': 'RECONCILIATION'
            },
            UpdateExpression='''
                SET exportJobId = :jobId,
                    exportJobStatus = :status,
                    exportCreatedAt = :createdAt,
                    reconciliationStatus = :reconcStatus,
                    sfExecutionArn = :execArn,
                    lastUpdated = :now,
                    callId = :callId,
                    dialogGroupId = :dgId,
                    #ttl = :ttl
            ''',
            ExpressionAttributeNames={
                '#ttl': 'TTL'
            },
            ExpressionAttributeValues={
                ':jobId': export_job_id,
                ':status': 'CREATED',
                ':createdAt': requested_at,
                ':reconcStatus': 'IN_PROGRESS',
                ':execArn': execution_arn,
                ':now': current_time,
                ':callId': call_id,
                ':dgId': dialog_group_id,
                ':ttl': ttl
            }
        )
        
        dynamo_update_success = True
        
        logger.info(json.dumps({
            'message': 'DynamoDB updated successfully',
            'dialogGroupId': dialog_group_id,
            'exportJobId': export_job_id
        }))
        
    except ClientError as e:
        # Log error but don't fail - export job was created successfully
        logger.error(json.dumps({
            'message': 'DynamoDB update failed',
            'error': str(e),
            'dialogGroupId': dialog_group_id,
            'exportJobId': export_job_id
        }))
        # We continue because the export job was created successfully
        # The Step Function will handle state tracking even if this update failed
    
    # Return result
    return {
        'exportJobId': export_job_id,
        'status': 'CREATED',
        'estimatedCompletionTime': estimated_completion,
        'dynamoUpdateSuccess': dynamo_update_success,
        'createdAt': requested_at
    }
