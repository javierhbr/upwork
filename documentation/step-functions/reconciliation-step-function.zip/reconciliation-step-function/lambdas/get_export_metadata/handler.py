"""
Lambda: GetExportMetadataFunction

Retrieves metadata from a completed OCP export job.
This runs in parallel with the download notification.

Input:
{
    "exportJobId": "EXP-JOB-9999",
    "dialogGroupId": "DG-2024-001234"
}

Output:
{
    "metadata": {
        "duration": 324,
        "channels": 2,
        "sampleRate": 8000,
        "format": "WAV",
        "agentId": "AGENT-001",
        "queueName": "Sales",
        "startTime": "2024-01-15T10:00:00Z",
        "endTime": "2024-01-15T10:05:24Z",
        "participants": [...]
    },
    "retrievedAt": "2024-01-15T10:42:30Z"
}
"""

import os
import json
import logging
from typing import Any, Dict

# Add shared utilities to path
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'shared'))

from utils import (
    lambda_handler_decorator,
    get_current_timestamp,
    get_ocp_client,
    OCPAPIError
)

logger = logging.getLogger()
logger.setLevel(os.environ.get('LOG_LEVEL', 'INFO'))


@lambda_handler_decorator
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Retrieves metadata from OCP export job.
    
    Args:
        event: Input containing exportJobId and dialogGroupId
        context: Lambda context
        
    Returns:
        Metadata information about the call
        
    Raises:
        OCPAPIError: If OCP API call fails
    """
    # Extract input parameters
    export_job_id = event['exportJobId']
    dialog_group_id = event['dialogGroupId']
    
    logger.info(json.dumps({
        'message': 'Retrieving export metadata',
        'exportJobId': export_job_id,
        'dialogGroupId': dialog_group_id
    }))
    
    # Query OCP for metadata
    ocp_client = get_ocp_client()
    
    try:
        metadata_response = ocp_client.get_export_metadata(export_job_id)
        
        # Extract and normalize metadata
        metadata = {
            # Audio properties
            'duration': metadata_response.get('duration'),
            'durationFormatted': format_duration(metadata_response.get('duration')),
            'channels': metadata_response.get('channels'),
            'sampleRate': metadata_response.get('sampleRate'),
            'bitRate': metadata_response.get('bitRate'),
            'format': metadata_response.get('format'),
            'fileSize': metadata_response.get('fileSize'),
            
            # Call properties
            'callId': metadata_response.get('callId'),
            'dialogGroupId': dialog_group_id,
            'direction': metadata_response.get('direction'),  # INBOUND/OUTBOUND
            'queueName': metadata_response.get('queueName'),
            'queueId': metadata_response.get('queueId'),
            
            # Timing
            'startTime': metadata_response.get('startTime'),
            'endTime': metadata_response.get('endTime'),
            'holdTime': metadata_response.get('holdTime'),
            'talkTime': metadata_response.get('talkTime'),
            'wrapUpTime': metadata_response.get('wrapUpTime'),
            
            # Participants
            'agentId': metadata_response.get('agentId'),
            'agentName': metadata_response.get('agentName'),
            'customerId': metadata_response.get('customerId'),
            'customerPhone': metadata_response.get('customerPhone'),
            'participants': metadata_response.get('participants', []),
            
            # Additional metadata
            'language': metadata_response.get('language'),
            'sentiment': metadata_response.get('sentiment'),
            'customAttributes': metadata_response.get('customAttributes', {}),
            
            # Transcript info (if available)
            'hasTranscript': metadata_response.get('hasTranscript', False),
            'transcriptLanguage': metadata_response.get('transcriptLanguage')
        }
        
        # Remove None values for cleaner output
        metadata = {k: v for k, v in metadata.items() if v is not None}
        
        logger.info(json.dumps({
            'message': 'Metadata retrieved successfully',
            'exportJobId': export_job_id,
            'dialogGroupId': dialog_group_id,
            'duration': metadata.get('duration'),
            'format': metadata.get('format')
        }))
        
        return {
            'metadata': metadata,
            'retrievedAt': get_current_timestamp(),
            'exportJobId': export_job_id,
            'dialogGroupId': dialog_group_id
        }
        
    except OCPAPIError as e:
        logger.error(json.dumps({
            'message': 'Failed to retrieve export metadata',
            'error': str(e),
            'exportJobId': export_job_id,
            'dialogGroupId': dialog_group_id
        }))
        raise


def format_duration(seconds: int) -> str:
    """
    Formats duration in seconds to HH:MM:SS string.
    
    Args:
        seconds: Duration in seconds
        
    Returns:
        Formatted duration string
    """
    if seconds is None:
        return None
    
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    
    if hours > 0:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    else:
        return f"{minutes:02d}:{secs:02d}"
