"""
Lambda: TriggerReconciliationFunction

Triggered by SQS to start Step Function executions for reconciliation requests.
Injects configuration parameters into the Step Function input.

SQS Message Format:
{
    "dialogGroupId": "DG-2024-001234",
    "callId": "CALL-5678-ABCD",
    "originalTimestamp": "2024-01-15T10:30:00Z",
    "retryAttempt": 0,
    "source": "RECONCILIATION_DETECTION"
}

Step Function Input (injected by this Lambda):
{
    "input": {
        "dialogGroupId": "DG-2024-001234",
        "callId": "CALL-5678-ABCD",
        ...
    },
    "config": {
        "globalTimeoutSeconds": 21600,
        "downloadTimeoutSeconds": 18000,
        "downloadHeartbeatSeconds": 600,
        "pollingIntervalSeconds": 300,
        "maxPollingRetries": 6,
        "tableName": "...",
        "dlqUrl": "..."
    }
}
"""

import os
import json
import logging
import uuid
from typing import Any, Dict, List

import boto3
from botocore.exceptions import ClientError

# Add shared utilities to path
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'shared'))

from utils import (
    lambda_handler_decorator,
    get_current_timestamp,
    AWSClients
)

logger = logging.getLogger()
logger.setLevel(os.environ.get('LOG_LEVEL', 'INFO'))

# Environment variables
STATE_MACHINE_ARN = os.environ.get('STATE_MACHINE_ARN')
TABLE_NAME = os.environ.get('TABLE_NAME')
DLQ_URL = os.environ.get('DLQ_URL')

# Timeout configuration from environment
GLOBAL_TIMEOUT_SECONDS = int(os.environ.get('GLOBAL_TIMEOUT_SECONDS', 21600))
DOWNLOAD_TIMEOUT_SECONDS = int(os.environ.get('DOWNLOAD_TIMEOUT_SECONDS', 18000))
DOWNLOAD_HEARTBEAT_SECONDS = int(os.environ.get('DOWNLOAD_HEARTBEAT_SECONDS', 600))
POLLING_INTERVAL_SECONDS = int(os.environ.get('POLLING_INTERVAL_SECONDS', 300))
MAX_POLLING_RETRIES = int(os.environ.get('MAX_POLLING_RETRIES', 6))


@lambda_handler_decorator
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Processes SQS messages and triggers Step Function executions.
    
    Args:
        event: SQS event containing records
        context: Lambda context
        
    Returns:
        Batch item failures for partial batch response
    """
    records = event.get('Records', [])
    
    logger.info(json.dumps({
        'message': 'Processing SQS batch',
        'recordCount': len(records)
    }))
    
    # Track failures for partial batch response
    batch_item_failures: List[Dict[str, str]] = []
    successful_count = 0
    
    for record in records:
        message_id = record.get('messageId')
        
        try:
            # Parse message body
            body = json.loads(record.get('body', '{}'))
            
            # Validate required fields
            dialog_group_id = body.get('dialogGroupId')
            call_id = body.get('callId')
            
            if not dialog_group_id or not call_id:
                logger.error(json.dumps({
                    'message': 'Invalid message - missing required fields',
                    'messageId': message_id,
                    'hasDialogGroupId': bool(dialog_group_id),
                    'hasCallId': bool(call_id)
                }))
                # Don't retry invalid messages - let them go to DLQ
                continue
            
            # Check if already processing (idempotency)
            if is_already_processing(dialog_group_id):
                logger.info(json.dumps({
                    'message': 'Skipping - already processing',
                    'dialogGroupId': dialog_group_id,
                    'messageId': message_id
                }))
                continue
            
            # Start Step Function execution
            execution_name = generate_execution_name(dialog_group_id, call_id)
            
            step_function_input = build_step_function_input(body)
            
            response = start_step_function_execution(
                execution_name=execution_name,
                input_data=step_function_input
            )
            
            logger.info(json.dumps({
                'message': 'Step Function execution started',
                'executionArn': response['executionArn'],
                'executionName': execution_name,
                'dialogGroupId': dialog_group_id,
                'callId': call_id
            }))
            
            successful_count += 1
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            
            if error_code == 'ExecutionAlreadyExists':
                # Execution already running - skip but don't fail
                logger.info(json.dumps({
                    'message': 'Execution already exists - skipping',
                    'messageId': message_id
                }))
                continue
            
            logger.error(json.dumps({
                'message': 'Failed to start Step Function execution',
                'error': str(e),
                'errorCode': error_code,
                'messageId': message_id
            }))
            
            # Add to failures for retry
            batch_item_failures.append({
                'itemIdentifier': message_id
            })
            
        except Exception as e:
            logger.error(json.dumps({
                'message': 'Unexpected error processing message',
                'error': str(e),
                'messageId': message_id
            }))
            
            # Add to failures for retry
            batch_item_failures.append({
                'itemIdentifier': message_id
            })
    
    logger.info(json.dumps({
        'message': 'Batch processing completed',
        'totalRecords': len(records),
        'successful': successful_count,
        'failed': len(batch_item_failures)
    }))
    
    # Return partial batch response
    return {
        'batchItemFailures': batch_item_failures
    }


def build_step_function_input(message_body: Dict[str, Any]) -> Dict[str, Any]:
    """
    Builds the Step Function input with configuration.
    
    Args:
        message_body: Original SQS message body
        
    Returns:
        Step Function input dictionary
    """
    return {
        'input': {
            'dialogGroupId': message_body['dialogGroupId'],
            'callId': message_body['callId'],
            'originalTimestamp': message_body.get('originalTimestamp'),
            'retryAttempt': message_body.get('retryAttempt', 0),
            'source': message_body.get('source', 'UNKNOWN'),
            'triggeredAt': get_current_timestamp()
        },
        'config': {
            'globalTimeoutSeconds': GLOBAL_TIMEOUT_SECONDS,
            'downloadTimeoutSeconds': DOWNLOAD_TIMEOUT_SECONDS,
            'downloadHeartbeatSeconds': DOWNLOAD_HEARTBEAT_SECONDS,
            'pollingIntervalSeconds': POLLING_INTERVAL_SECONDS,
            'maxPollingRetries': MAX_POLLING_RETRIES,
            'tableName': TABLE_NAME,
            'dlqUrl': DLQ_URL
        }
    }


def generate_execution_name(dialog_group_id: str, call_id: str) -> str:
    """
    Generates a unique execution name for Step Functions.
    
    The name must be unique within the state machine and can be used
    for idempotency. Format: {dialogGroupId}-{shortUUID}
    
    Args:
        dialog_group_id: Dialog group identifier
        call_id: Call identifier
        
    Returns:
        Unique execution name (max 80 chars, alphanumeric + hyphens)
    """
    # Clean dialog group ID (remove special chars)
    clean_dg = ''.join(c if c.isalnum() else '-' for c in dialog_group_id)
    
    # Generate short unique suffix
    short_uuid = uuid.uuid4().hex[:8]
    
    # Combine and truncate to 80 chars max
    execution_name = f"{clean_dg}-{short_uuid}"[:80]
    
    return execution_name


def start_step_function_execution(
    execution_name: str,
    input_data: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Starts a Step Function execution.
    
    Args:
        execution_name: Unique execution name
        input_data: Input data for the execution
        
    Returns:
        StartExecution response
        
    Raises:
        ClientError: If execution fails to start
    """
    sfn_client = AWSClients.step_functions()
    
    response = sfn_client.start_execution(
        stateMachineArn=STATE_MACHINE_ARN,
        name=execution_name,
        input=json.dumps(input_data)
    )
    
    return response


def is_already_processing(dialog_group_id: str) -> bool:
    """
    Checks if a reconciliation is already in progress for this dialog group.
    
    Args:
        dialog_group_id: Dialog group identifier
        
    Returns:
        True if already processing, False otherwise
    """
    try:
        table = AWSClients.dynamodb().Table(TABLE_NAME)
        
        response = table.get_item(
            Key={
                'PK': f'CALL#{dialog_group_id}',
                'SK': 'RECONCILIATION'
            },
            ProjectionExpression='reconciliationStatus'
        )
        
        item = response.get('Item')
        if not item:
            return False
        
        status = item.get('reconciliationStatus')
        
        # Consider these statuses as "already processing"
        active_statuses = {'IN_PROGRESS', 'POLLING', 'EXPORT_COMPLETED', 'DOWNLOADING'}
        
        return status in active_statuses
        
    except ClientError as e:
        logger.warning(json.dumps({
            'message': 'Failed to check processing status',
            'error': str(e),
            'dialogGroupId': dialog_group_id
        }))
        # On error, allow processing to proceed
        return False
