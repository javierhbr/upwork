"""
Lambda: CheckExportStatusFunction

Checks the status of an export job in OCP Export API.
This is called repeatedly in the polling loop.

Input:
{
    "exportJobId": "EXP-JOB-9999",
    "dialogGroupId": "DG-2024-001234"
}

Output (In Progress):
{
    "status": "IN_PROGRESS",
    "progress": 45,
    "estimatedSecondsRemaining": 180
}

Output (Completed):
{
    "status": "COMPLETED",
    "downloadUrl": "https://ocp-export.example.com/files/EXP-JOB-9999.zip",
    "fileSize": 15728640,
    "completedAt": "2024-01-15T10:42:00Z"
}

Output (Failed):
{
    "status": "FAILED",
    "errorMessage": "Audio file not found in storage"
}
"""

import os
import json
import logging
from typing import Any, Dict

# Add shared utilities to path
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'shared'))

from utils import (
    lambda_handler_decorator,
    get_current_timestamp,
    get_ocp_client,
    OCPAPIError
)

logger = logging.getLogger()
logger.setLevel(os.environ.get('LOG_LEVEL', 'INFO'))


@lambda_handler_decorator
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Checks export job status in OCP.
    
    Args:
        event: Input containing exportJobId and dialogGroupId
        context: Lambda context
        
    Returns:
        Status information including status, progress, downloadUrl
        
    Raises:
        OCPAPIError: If OCP API call fails
    """
    # Extract input parameters
    export_job_id = event['exportJobId']
    dialog_group_id = event['dialogGroupId']
    
    logger.info(json.dumps({
        'message': 'Checking export job status',
        'exportJobId': export_job_id,
        'dialogGroupId': dialog_group_id
    }))
    
    # Query OCP for status
    ocp_client = get_ocp_client()
    
    try:
        status_response = ocp_client.get_export_status(export_job_id)
        
        status = status_response.get('status', 'UNKNOWN')
        
        logger.info(json.dumps({
            'message': 'Export job status retrieved',
            'exportJobId': export_job_id,
            'status': status,
            'progress': status_response.get('progress')
        }))
        
        # Build response based on status
        result = {
            'status': status,
            'checkedAt': get_current_timestamp()
        }
        
        if status == 'IN_PROGRESS':
            result['progress'] = status_response.get('progress', 0)
            result['estimatedSecondsRemaining'] = status_response.get('estimatedSecondsRemaining')
            
        elif status == 'COMPLETED':
            result['downloadUrl'] = status_response.get('downloadUrl')
            result['fileSize'] = status_response.get('fileSize')
            result['completedAt'] = status_response.get('completedAt', get_current_timestamp())
            result['checksum'] = status_response.get('checksum')
            
            if not result['downloadUrl']:
                logger.warning(json.dumps({
                    'message': 'Export completed but no download URL provided',
                    'exportJobId': export_job_id
                }))
            
        elif status == 'FAILED':
            result['errorMessage'] = status_response.get('errorMessage', 'Unknown error')
            result['errorCode'] = status_response.get('errorCode')
            
            logger.warning(json.dumps({
                'message': 'Export job failed',
                'exportJobId': export_job_id,
                'errorMessage': result['errorMessage']
            }))
        
        else:
            # Unknown status
            logger.warning(json.dumps({
                'message': 'Unknown export job status',
                'exportJobId': export_job_id,
                'status': status
            }))
        
        return result
        
    except OCPAPIError as e:
        logger.error(json.dumps({
            'message': 'Failed to check export job status',
            'error': str(e),
            'exportJobId': export_job_id,
            'dialogGroupId': dialog_group_id
        }))
        raise
