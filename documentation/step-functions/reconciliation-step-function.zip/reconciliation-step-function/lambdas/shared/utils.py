"""
Shared utilities and custom exceptions for reconciliation Lambda functions.
"""

import json
import os
import logging
from datetime import datetime, timezone
from functools import wraps
from typing import Any, Dict, Optional

import boto3
from botocore.exceptions import ClientError

# Configure logging
logger = logging.getLogger()
logger.setLevel(os.environ.get('LOG_LEVEL', 'INFO'))


# ============================================================================
# CUSTOM EXCEPTIONS
# ============================================================================

class OCPAPIError(Exception):
    """Base exception for OCP API errors."""
    pass


class OCPAPITimeoutError(OCPAPIError):
    """Raised when OCP API request times out."""
    pass


class OCPAPIThrottlingError(OCPAPIError):
    """Raised when OCP API throttles the request."""
    pass


class OCPAPIServerError(OCPAPIError):
    """Raised when OCP API returns a server error (5xx)."""
    pass


class DownloadServiceError(Exception):
    """Raised when download service encounters an error."""
    pass


class DynamoDBError(Exception):
    """Raised when DynamoDB operation fails."""
    pass


# ============================================================================
# DECORATORS
# ============================================================================

def lambda_handler_decorator(func):
    """
    Decorator for Lambda handlers that provides:
    - Structured logging
    - Exception handling with proper error responses
    - Request/response logging
    """
    @wraps(func)
    def wrapper(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
        request_id = context.aws_request_id if context else 'local'
        
        logger.info(json.dumps({
            'message': 'Lambda invocation started',
            'request_id': request_id,
            'function_name': context.function_name if context else 'local',
            'event_keys': list(event.keys()) if isinstance(event, dict) else 'non-dict'
        }))
        
        try:
            result = func(event, context)
            
            logger.info(json.dumps({
                'message': 'Lambda invocation completed',
                'request_id': request_id,
                'result_keys': list(result.keys()) if isinstance(result, dict) else 'non-dict'
            }))
            
            return result
            
        except OCPAPIThrottlingError as e:
            logger.warning(f'OCP API throttling: {str(e)}')
            raise
        except OCPAPITimeoutError as e:
            logger.warning(f'OCP API timeout: {str(e)}')
            raise
        except OCPAPIError as e:
            logger.error(f'OCP API error: {str(e)}')
            raise
        except Exception as e:
            logger.exception(f'Unexpected error: {str(e)}')
            raise
    
    return wrapper


# ============================================================================
# HELPERS
# ============================================================================

def get_current_timestamp() -> str:
    """Returns current UTC timestamp in ISO 8601 format."""
    return datetime.now(timezone.utc).isoformat()


def get_ttl_timestamp(days: int = 30) -> int:
    """Returns TTL timestamp (epoch seconds) for DynamoDB."""
    from datetime import timedelta
    future = datetime.now(timezone.utc) + timedelta(days=days)
    return int(future.timestamp())


def safe_get(d: Dict, *keys, default=None) -> Any:
    """Safely get nested dictionary values."""
    for key in keys:
        if isinstance(d, dict):
            d = d.get(key, default)
        else:
            return default
    return d


# ============================================================================
# AWS CLIENTS
# ============================================================================

class AWSClients:
    """Lazy-loaded AWS clients for Lambda reuse."""
    
    _dynamodb = None
    _sqs = None
    _secrets_manager = None
    _step_functions = None
    
    @classmethod
    def dynamodb(cls):
        if cls._dynamodb is None:
            cls._dynamodb = boto3.resource('dynamodb')
        return cls._dynamodb
    
    @classmethod
    def dynamodb_client(cls):
        return boto3.client('dynamodb')
    
    @classmethod
    def sqs(cls):
        if cls._sqs is None:
            cls._sqs = boto3.client('sqs')
        return cls._sqs
    
    @classmethod
    def secrets_manager(cls):
        if cls._secrets_manager is None:
            cls._secrets_manager = boto3.client('secretsmanager')
        return cls._secrets_manager
    
    @classmethod
    def step_functions(cls):
        if cls._step_functions is None:
            cls._step_functions = boto3.client('stepfunctions')
        return cls._step_functions


# ============================================================================
# SECRETS MANAGER
# ============================================================================

_secrets_cache: Dict[str, str] = {}

def get_secret(secret_arn: str) -> str:
    """
    Retrieves secret from Secrets Manager with caching.
    
    Args:
        secret_arn: ARN of the secret
        
    Returns:
        Secret value as string
    """
    if secret_arn in _secrets_cache:
        return _secrets_cache[secret_arn]
    
    try:
        response = AWSClients.secrets_manager().get_secret_value(
            SecretId=secret_arn
        )
        secret = response['SecretString']
        _secrets_cache[secret_arn] = secret
        return secret
    except ClientError as e:
        logger.error(f'Failed to retrieve secret: {str(e)}')
        raise


# ============================================================================
# OCP API CLIENT
# ============================================================================

class OCPExportClient:
    """
    Client for interacting with OCP Export API.
    
    This is a placeholder implementation. Replace with actual OCP API calls.
    """
    
    def __init__(self, api_endpoint: str, api_key: str):
        self.api_endpoint = api_endpoint
        self.api_key = api_key
        self.timeout = 30  # seconds
    
    def create_export_job(self, dialog_group_id: str, call_id: str) -> Dict[str, Any]:
        """
        Creates an export job in OCP.
        
        Args:
            dialog_group_id: Dialog group identifier
            call_id: Call identifier
            
        Returns:
            Dict with exportJobId, status, estimatedCompletionTime
            
        Raises:
            OCPAPIError: If API call fails
        """
        import requests
        from requests.exceptions import Timeout, RequestException
        
        try:
            url = f"{self.api_endpoint}/export/jobs"
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json'
            }
            payload = {
                'dialogGroupId': dialog_group_id,
                'callId': call_id,
                'includeAudio': True,
                'includeTranscript': True
            }
            
            response = requests.post(
                url,
                headers=headers,
                json=payload,
                timeout=self.timeout
            )
            
            if response.status_code == 429:
                raise OCPAPIThrottlingError('OCP API rate limit exceeded')
            
            if response.status_code >= 500:
                raise OCPAPIServerError(f'OCP API server error: {response.status_code}')
            
            if response.status_code != 200 and response.status_code != 201:
                raise OCPAPIError(f'OCP API error: {response.status_code} - {response.text}')
            
            return response.json()
            
        except Timeout:
            raise OCPAPITimeoutError('OCP API request timed out')
        except RequestException as e:
            raise OCPAPIError(f'OCP API request failed: {str(e)}')
    
    def get_export_status(self, export_job_id: str) -> Dict[str, Any]:
        """
        Gets the status of an export job.
        
        Args:
            export_job_id: Export job identifier
            
        Returns:
            Dict with status, progress, downloadUrl (if completed), errorMessage (if failed)
            
        Raises:
            OCPAPIError: If API call fails
        """
        import requests
        from requests.exceptions import Timeout, RequestException
        
        try:
            url = f"{self.api_endpoint}/export/jobs/{export_job_id}/status"
            headers = {
                'Authorization': f'Bearer {self.api_key}'
            }
            
            response = requests.get(
                url,
                headers=headers,
                timeout=self.timeout
            )
            
            if response.status_code == 429:
                raise OCPAPIThrottlingError('OCP API rate limit exceeded')
            
            if response.status_code >= 500:
                raise OCPAPIServerError(f'OCP API server error: {response.status_code}')
            
            if response.status_code != 200:
                raise OCPAPIError(f'OCP API error: {response.status_code} - {response.text}')
            
            return response.json()
            
        except Timeout:
            raise OCPAPITimeoutError('OCP API request timed out')
        except RequestException as e:
            raise OCPAPIError(f'OCP API request failed: {str(e)}')
    
    def get_export_metadata(self, export_job_id: str) -> Dict[str, Any]:
        """
        Gets metadata for a completed export job.
        
        Args:
            export_job_id: Export job identifier
            
        Returns:
            Dict with call metadata (duration, channels, format, etc.)
            
        Raises:
            OCPAPIError: If API call fails
        """
        import requests
        from requests.exceptions import Timeout, RequestException
        
        try:
            url = f"{self.api_endpoint}/export/jobs/{export_job_id}/metadata"
            headers = {
                'Authorization': f'Bearer {self.api_key}'
            }
            
            response = requests.get(
                url,
                headers=headers,
                timeout=self.timeout
            )
            
            if response.status_code == 429:
                raise OCPAPIThrottlingError('OCP API rate limit exceeded')
            
            if response.status_code >= 500:
                raise OCPAPIServerError(f'OCP API server error: {response.status_code}')
            
            if response.status_code != 200:
                raise OCPAPIError(f'OCP API error: {response.status_code} - {response.text}')
            
            return response.json()
            
        except Timeout:
            raise OCPAPITimeoutError('OCP API request timed out')
        except RequestException as e:
            raise OCPAPIError(f'OCP API request failed: {str(e)}')


def get_ocp_client() -> OCPExportClient:
    """Factory function to create OCP client with credentials from environment."""
    api_endpoint = os.environ.get('OCP_API_ENDPOINT')
    api_key_secret_arn = os.environ.get('OCP_API_KEY_SECRET_ARN')
    
    if not api_endpoint or not api_key_secret_arn:
        raise ValueError('OCP_API_ENDPOINT and OCP_API_KEY_SECRET_ARN must be set')
    
    api_key = get_secret(api_key_secret_arn)
    return OCPExportClient(api_endpoint, api_key)
