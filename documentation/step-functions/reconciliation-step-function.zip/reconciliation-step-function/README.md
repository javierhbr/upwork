# Audio File Reconciliation Process

AWS Step Functions implementation for reconciling audio files from OCP (Omilia Cloud Platform) when the primary ingestion flow fails.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                     RECONCILIATION PROCESS ARCHITECTURE                          │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│   ┌─────────┐    ┌─────────────┐    ┌──────────────────────────────────────┐   │
│   │   SQS   │───►│   Lambda    │───►│         STEP FUNCTION                │   │
│   │  Queue  │    │  (Trigger)  │    │                                      │   │
│   └─────────┘    └─────────────┘    │  1. CreateExportJobAndUpdateStatus   │   │
│                                      │  2. Polling Loop (Wait + Check)      │   │
│                                      │  3. Parallel Processing               │   │
│                                      │     ├─ GetMetadata                   │   │
│                                      │     └─ NotifyDownload + Callback     │   │
│                                      │  4. UpdateFinalStatus                │   │
│                                      └──────────────────────────────────────┘   │
│                                                     │                            │
│                                                     ▼                            │
│                                      ┌──────────────────────────────┐           │
│                                      │       Fargate Service        │           │
│                                      │   (Orchestrator + Worker)    │           │
│                                      └──────────────────────────────┘           │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

## Features

- **Configurable Timeouts**: All timeouts are configurable via CloudFormation parameters
- **Native Wait States**: Uses Step Functions Wait states for polling (no EventBridge)
- **Heartbeat Monitoring**: Detects stuck downloads via heartbeat pattern
- **Comprehensive Error Handling**: All error paths route to DLQ with full context
- **Idempotency**: Prevents duplicate processing of same dialog group
- **Observability**: Full CloudWatch logging, X-Ray tracing, and alarms

## Timeout Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `GlobalExecutionTimeoutSeconds` | 21600 (6 hours) | Maximum total execution time |
| `DownloadTimeoutSeconds` | 18000 (5 hours) | Maximum time for download completion |
| `DownloadHeartbeatSeconds` | 600 (10 min) | Heartbeat interval for download monitoring |
| `PollingIntervalSeconds` | 300 (5 min) | Wait time between status checks |
| `MaxPollingRetries` | 6 | Maximum polling attempts |

### Timeline Visualization

```
0        30min              5h                    6h
│─────────│──────────────────│─────────────────────│
│         │                  │                     │
│ Polling │    Download      │    Buffer           │
│ (max)   │    (max)         │                     │
└─────────┴──────────────────┴─────────────────────┘
CreateJob  Export Complete   Download Complete    Global Timeout
```

## Project Structure

```
reconciliation-step-function/
├── template.yaml                    # CloudFormation/SAM template
├── state-machine/
│   └── reconciliation-state-machine.asl.json  # Step Function definition
├── lambdas/
│   ├── requirements.txt             # Python dependencies
│   ├── shared/
│   │   └── utils.py                 # Shared utilities and OCP client
│   ├── create_export_job/
│   │   └── handler.py               # Creates OCP export job
│   ├── check_export_status/
│   │   └── handler.py               # Checks export job status
│   ├── get_export_metadata/
│   │   └── handler.py               # Retrieves call metadata
│   ├── notify_download_service/
│   │   └── handler.py               # Notifies Fargate and stores task token
│   ├── process_parallel_results/
│   │   └── handler.py               # Consolidates parallel branch results
│   └── trigger_reconciliation/
│       └── handler.py               # SQS trigger for Step Function
└── README.md
```

## Deployment

### Prerequisites

- AWS SAM CLI installed
- AWS credentials configured
- S3 bucket for deployment artifacts

### Deploy

```bash
# Build
sam build

# Deploy (guided for first time)
sam deploy --guided

# Deploy with parameters
sam deploy \
  --stack-name reconciliation-prod \
  --parameter-overrides \
    Environment=prod \
    GlobalExecutionTimeoutSeconds=21600 \
    DownloadTimeoutSeconds=18000 \
    PollingIntervalSeconds=300 \
    MaxPollingRetries=6 \
    OCPApiEndpoint=https://ocp-api.example.com \
    OCPApiKey=your-api-key \
    DownloadServiceQueueUrl=https://sqs...
```

### Environment Variables

Each Lambda function requires specific environment variables:

| Variable | Lambda Functions | Description |
|----------|------------------|-------------|
| `OCP_API_ENDPOINT` | create_export_job, check_export_status, get_export_metadata | OCP Export API base URL |
| `OCP_API_KEY_SECRET_ARN` | create_export_job, check_export_status, get_export_metadata | Secrets Manager ARN for API key |
| `TABLE_NAME` | All functions | DynamoDB table name |
| `DOWNLOAD_SERVICE_QUEUE_URL` | notify_download_service | SQS queue for Fargate |
| `STATE_MACHINE_ARN` | trigger_reconciliation | Step Function ARN |
| `DLQ_URL` | trigger_reconciliation | Dead Letter Queue URL |

## DynamoDB Schema

### Main Record (Call Reconciliation)

| Attribute | Type | Description |
|-----------|------|-------------|
| PK | String | `CALL#{dialogGroupId}` |
| SK | String | `RECONCILIATION` |
| dialogGroupId | String | Dialog group identifier |
| callId | String | Call identifier |
| exportJobId | String | OCP export job ID |
| exportJobStatus | String | CREATED, POLLING, EXPORT_COMPLETED |
| reconciliationStatus | String | IN_PROGRESS, COMPLETED, FAILED_* |
| pollingIteration | Number | Current polling count |
| downloadStatus | String | INITIATED, COMPLETED, FAILED |
| downloadLocation | String | S3 path to downloaded file |
| metadata | String | JSON string of call metadata |
| sfExecutionArn | String | Step Function execution ARN |
| lastUpdated | String | ISO 8601 timestamp |
| TTL | Number | Epoch timestamp for auto-cleanup |

### Task Token Record (for recovery)

| Attribute | Type | Description |
|-----------|------|-------------|
| PK | String | `TASK#{downloadTaskId}` |
| SK | String | `TOKEN` |
| taskToken | String | Step Functions task token |
| dialogGroupId | String | Dialog group identifier |
| exportJobId | String | Export job identifier |
| status | String | PENDING, COMPLETED |
| TTL | Number | Epoch timestamp (24h) |

## Fargate Callback Integration

The Fargate download service must send callbacks to Step Functions:

### On Success

```bash
aws stepfunctions send-task-success \
  --task-token "AAAA...taskToken...ZZZZ" \
  --task-output '{"status":"SUCCESS","downloadLocation":"s3://bucket/file.wav","fileSize":15728640}'
```

### On Failure

```bash
aws stepfunctions send-task-failure \
  --task-token "AAAA...taskToken...ZZZZ" \
  --error "DownloadFailed" \
  --cause "Connection timeout to OCP server"
```

### Heartbeat (while processing)

```bash
aws stepfunctions send-task-heartbeat \
  --task-token "AAAA...taskToken...ZZZZ"
```

## Error Handling

All errors route to a Dead Letter Queue with full context:

```json
{
  "dialogGroupId": "DG-2024-001234",
  "callId": "CALL-5678-ABCD",
  "exportJobId": "EXP-JOB-9999",
  "reconciliationStatus": "FAILED_DOWNLOAD_TIMEOUT",
  "failureReason": "Download did not complete within 18000 seconds",
  "executionId": "arn:aws:states:...",
  "config": { ... },
  "failedAt": "2024-01-15T16:30:00Z",
  "retryCount": 3
}
```

### Failure Status Codes

| Status | Description |
|--------|-------------|
| `FAILED_OCP_API_ERROR` | Failed to create export job in OCP |
| `FAILED_EXPORT_ERROR` | OCP export job failed |
| `FAILED_MAX_RETRIES` | Export job didn't complete within polling attempts |
| `FAILED_UNKNOWN_STATUS` | Export job returned unexpected status |
| `FAILED_DOWNLOAD_TIMEOUT` | Download exceeded timeout |
| `FAILED_DOWNLOAD_HEARTBEAT_TIMEOUT` | Download service stopped responding |
| `FAILED_DOWNLOAD_SERVICE_ERROR` | Download service reported error |
| `FAILED_PARALLEL_ERROR` | Error in parallel processing |
| `FAILED_UNEXPECTED_ERROR` | Catch-all for unexpected errors |

## Monitoring

### CloudWatch Alarms

The template creates the following alarms:

- **Failed Executions**: Triggers when >5 executions fail in 5 minutes
- **Timed Out Executions**: Triggers when >3 executions timeout in 5 minutes
- **DLQ Depth**: Triggers when >10 messages in DLQ

### X-Ray Tracing

X-Ray tracing is enabled on all Lambda functions and the Step Function.

### Useful CloudWatch Insights Queries

```sql
-- Find all failed reconciliations
fields @timestamp, @message
| filter @message like /reconciliationStatus.*FAILED/
| sort @timestamp desc
| limit 100

-- Check polling iterations
fields @timestamp, dialogGroupId, pollingIteration
| filter @message like /pollingIteration/
| stats max(pollingIteration) by dialogGroupId

-- Download timeouts
fields @timestamp, dialogGroupId, exportJobId
| filter @message like /DOWNLOAD_TIMEOUT/
| sort @timestamp desc
```

## Cost Estimation

For 10K reconciliations/day with average 3 polling iterations:

| Component | Calculation | Monthly Cost |
|-----------|-------------|--------------|
| Step Functions | 10K × 27 transitions × 30 = 8.1M | ~$200 |
| Lambda | 10K × 15 invocations × 30 = 4.5M | ~$1 |
| DynamoDB | ~8 writes/exec = 2.4M WCU | ~$3 |
| SQS | Minimal | <$1 |
| **Total** | | **~$210/month** |

## Local Development

### Run Tests

```bash
cd lambdas
pip install -r requirements.txt
pytest tests/ -v --cov=.
```

### Local Invocation

```bash
# Using SAM CLI
sam local invoke CreateExportJobFunction \
  --event events/create_export_job_event.json

# Using AWS CLI (against deployed function)
aws lambda invoke \
  --function-name dev-create-export-job \
  --payload file://events/create_export_job_event.json \
  response.json
```

## Troubleshooting

### Common Issues

1. **Execution times out immediately**
   - Check that `globalTimeoutSeconds` in config is correct
   - Verify Step Function definition has `TimeoutSecondsPath`

2. **Download never completes**
   - Verify Fargate service is receiving messages from SQS
   - Check Fargate logs for errors
   - Confirm task token is being stored correctly

3. **Heartbeat timeout fires too early**
   - Increase `downloadHeartbeatSeconds`
   - Verify Fargate is sending heartbeats

4. **Duplicate processing**
   - Check idempotency logic in trigger function
   - Verify DynamoDB status checks

## License

MIT License - See LICENSE file for details
