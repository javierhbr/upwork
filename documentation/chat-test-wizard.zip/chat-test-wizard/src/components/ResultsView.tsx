
import React from 'react';
import { CheckCircle, X } from 'lucide-react';
import { SimulationResult, RunConfig } from '../types';

interface ResultsViewProps {
    simulationResult: SimulationResult;
    runConfig: RunConfig;
    closeRunner: () => void;
}

export const ResultsView: React.FC<ResultsViewProps> = ({ simulationResult, runConfig, closeRunner }) => {
    return (
        <div className="flex flex-col h-screen bg-white font-sans overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white z-10">
                <div className="flex items-center gap-4">
                    <div className="text-3xl font-bold text-slate-800">1</div>
                    <CheckCircle className="w-8 h-8 text-green-500" />
                    <div>
                        <h1 className="text-2xl font-bold text-slate-800">{simulationResult.chatTitle}</h1>
                        <span className="text-sm text-slate-500">{runConfig.label}</span>
                    </div>
                </div>
                <button onClick={closeRunner} className="px-4 py-2 border border-slate-300 rounded hover:bg-slate-50 text-slate-700">
                    <X className="w-5 h-5" />
                </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 bg-slate-50">
                <div className="max-w-6xl mx-auto space-y-6">
                    <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
                        <div className="p-3 bg-slate-50 border-b border-slate-200 text-xs font-bold text-blue-600 uppercase">
                            [+] Click to see chat details
                        </div>
                        <div className="p-6 space-y-4">
                            <div className="flex">
                                <div className="w-48 text-sm text-slate-500">dialog_id</div>
                                <div className="flex-1 bg-slate-100 rounded px-3 py-1 text-sm font-mono text-slate-700 truncate">
                                    {simulationResult.dialogId}
                                </div>
                            </div>

                            <div className="flex">
                                <div className="w-48 text-sm text-slate-500">input_variables</div>
                                <div className="flex-1 space-y-2">
                                    {Object.entries(simulationResult.inputVariables).map(([k, v]) => (
                                        <div key={k} className="flex items-center bg-slate-50 rounded border border-slate-100 p-1">
                                            <span className="w-32 text-xs font-semibold text-slate-600 pl-2">{k}</span>
                                            <span className="text-sm text-slate-800 font-mono bg-white px-2 rounded flex-1">{String(v)}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="flex">
                                <div className="w-48 text-sm text-slate-500">startTime</div>
                                <div className="flex-1 bg-slate-100 rounded px-3 py-1 text-sm font-mono text-slate-700">
                                    {simulationResult.startTime}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h2 className="text-xl font-bold text-slate-800 mb-4">Conversation</h2>
                        <div className="bg-white rounded-lg shadow-sm overflow-hidden border border-slate-200">
                            <table className="w-full text-left">
                                <thead>
                                    <tr className="bg-white border-b border-slate-200">
                                        <th className="px-4 py-3 text-sm font-medium text-slate-600 w-32">Message Time (ms)</th>
                                        <th className="px-4 py-3 text-sm font-medium text-slate-600 w-24">Source</th>
                                        <th className="px-4 py-3 text-sm font-medium text-slate-600">Message</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {simulationResult.messages.map((row, i) => (
                                        <tr key={i} className="border-b border-slate-100 last:border-0 hover:bg-slate-50 bg-green-100/30">
                                            <td className="px-4 py-3 text-sm font-mono text-slate-700">{row.time}</td>
                                            <td className="px-4 py-3 text-sm font-bold text-slate-600 uppercase">{row.source}</td>
                                            <td className="px-4 py-3 text-sm text-slate-800">{row.message}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
