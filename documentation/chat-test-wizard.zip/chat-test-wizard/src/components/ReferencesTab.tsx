
import React, { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Chat } from '../types';

interface ReferencesTabProps {
    activeChat: Chat;
    activeRefKey: string | null;
    setActiveRefKey: (key: string | null) => void;
    availableRefs: string[];
    allTestParams: { [key: string]: any };
    requestDelete: (type: string, key: string, e?: React.MouseEvent) => void;
    confirmCreateReference: (key: string) => void;
    addRefMessageStep: (type: 'bot' | 'user') => void;
    updateRefMessageStep: (msgIndex: number, key: string, val: string) => void;
    deleteRefMessageStep: (msgIndex: number) => void;
}

export const ReferencesTab: React.FC<ReferencesTabProps> = ({
    activeChat,
    activeRefKey,
    setActiveRefKey,
    availableRefs,
    allTestParams,
    requestDelete,
    confirmCreateReference,
    addRefMessageStep,
    updateRefMessageStep,
    deleteRefMessageStep,
}) => {
    const [isCreatingRef, setIsCreatingRef] = useState(false);
    const [newRefName, setNewRefName] = useState("");

    const handleConfirmCreateReference = () => {
        if (!newRefName.trim()) {
            setIsCreatingRef(false);
            return;
        }
        confirmCreateReference(newRefName);
        setNewRefName("");
        setIsCreatingRef(false);
    }

    return (
        <div className="flex gap-6 h-[calc(100vh-14rem)]">
            <div className="w-1/3 bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col">
                <div className="p-3 border-b border-slate-100 flex justify-between items-center bg-slate-50 rounded-t-xl">
                    <span className="text-xs font-bold text-slate-500 uppercase">Available References</span>
                    <button onClick={() => setIsCreatingRef(true)} className="text-blue-600 hover:bg-blue-50 p-1 rounded"><Plus className="w-4 h-4" /></button>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-1">
                    {isCreatingRef && <input autoFocus className="w-full p-2 text-sm border border-blue-400 rounded shadow-sm outline-none" placeholder="Enter Name..." value={newRefName} onChange={e => setNewRefName(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') handleConfirmCreateReference(); }} />}
                    {availableRefs.map(ref => (
                        <div key={ref} onClick={() => setActiveRefKey(ref)} className={`p-3 rounded-md text-sm flex justify-between cursor-pointer ${activeRefKey === ref ? 'bg-blue-50 text-blue-700' : 'hover:bg-slate-50'}`}>
                            <span>{ref}</span> <Trash2 className="w-3 h-3 text-slate-400 hover:text-red-500" onClick={(e) => requestDelete('reference', ref, e)} />
                        </div>
                    ))}
                </div>
            </div>
            <div className="flex-1 bg-white rounded-xl shadow-sm border border-slate-200 p-4">
                {activeRefKey ? (
                    <div className="space-y-2">
                        <h3 className="font-mono text-blue-600 mb-4">{activeRefKey}</h3>
                        {(allTestParams[activeRefKey]?.messages || []).map((msg: any, idx: number) => (
                            <div key={idx} className="flex gap-2">
                                <span className={`text-xs font-bold px-2 py-1 rounded ${msg.bot ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}`}>{msg.bot ? 'BOT' : 'USER'}</span>
                                <input className="flex-1 border-b bg-transparent" value={msg.bot || msg.user} onChange={(e) => updateRefMessageStep(idx, msg.bot ? 'bot' : 'user', e.target.value)} />
                                <Trash2 className="w-4 h-4 text-slate-300 hover:text-red-500 cursor-pointer" onClick={() => deleteRefMessageStep(idx)} />
                            </div>
                        ))}
                        <button onClick={() => addRefMessageStep('bot')} className="text-xs text-blue-600 mt-2">+ Bot</button>
                        <button onClick={() => addRefMessageStep('user')} className="text-xs text-green-600 mt-2 ml-2">+ User</button>
                    </div>
                ) : <div className="text-slate-400 text-center mt-10">Select a reference</div>}
            </div>
        </div>
    );
};
