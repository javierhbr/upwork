
import React from 'react';
import { Trash2 } from 'lucide-react';

interface DeleteModalProps {
    deleteTarget: { type: string; key: string } | null;
    setDeleteTarget: (target: { type: string; key: string } | null) => void;
    confirmDelete: () => void;
}

export const DeleteModal: React.FC<DeleteModalProps> = ({ deleteTarget, setDeleteTarget, confirmDelete }) => {
    if (!deleteTarget) return null;

    return (
        <div className="absolute inset-0 bg-slate-900/30 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in duration-200">
            <div className="bg-white rounded-xl shadow-xl border border-slate-200 p-6 w-80">
                <div className="flex flex-col items-center text-center gap-4">
                    <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center text-red-600">
                        <Trash2 className="w-6 h-6" />
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-slate-800">Delete Item?</h3>
                        <p className="text-sm text-slate-500 mt-1">Permanently remove <span className="font-mono font-bold">{deleteTarget.key}</span>?</p>
                    </div>
                    <div className="flex gap-3 w-full">
                        <button onClick={() => setDeleteTarget(null)} className="flex-1 py-2 bg-white border rounded text-slate-700">Cancel</button>
                        <button onClick={confirmDelete} className="flex-1 py-2 bg-red-600 text-white rounded">Delete</button>
                    </div>
                </div>
            </div>
        </div>
    );
};
