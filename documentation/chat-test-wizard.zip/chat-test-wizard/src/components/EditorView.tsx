
import React, { useState } from 'react';
import { Header } from './Header';
import { Sidebar } from './Sidebar';
import { DeleteModal } from './DeleteModal';
import { FlowTab } from './FlowTab';
import { ParamsTab } from './ParamsTab';
import { ReferencesTab } from './ReferencesTab';
import { SettingsTab } from './SettingsTab';
import { useYamlData } from '../hooks/useYamlData';
import { useChatState } from '../hooks/useChatState';
import { useRunnerState } from '../hooks/useRunnerState';
import { YamlData, Chat } from '../types';

export const EditorView: React.FC = () => {
    const { data, setData, isYamlLoaded, handleFileUpload, handleDownload } = useYamlData();
    const {
        activeChatIndex,
        setActiveChatIndex,
        activeRefKey,
        setActiveRefKey,
        activeChat,
        updateChat,
        addMessageStep,
        updateMessageStep,
        deleteMessageStep,
        moveMessageStep,
        deleteTarget,
        requestDelete,
        confirmDelete,
        confirmCreateVariable,
        confirmCreateTestParam,
        confirmCreateReference,
        addRefMessageStep,
        updateRefMessageStep,
        deleteRefMessageStep,
        updateInputVariable,
        updateTestParameter,
        insertParam,
        toggleParameterized,
        setDeleteTarget,
    } = useChatState(data, setData as (data: YamlData) => void);
    const { initiateRun } = useRunnerState(activeChat);

    const [activeTab, setActiveTab] = useState('flow');

    const getInputVariables = (chat: Chat) => {
        if (chat.input_variables) return chat.input_variables;
        if (chat.test_parameters && chat.test_parameters.input_variables) return chat.test_parameters.input_variables as { [key: string]: string};
        return {};
    };

    const inputVars = getInputVariables(activeChat);
    const allTestParams = activeChat?.test_parameters || {};

    const availableRefs = Object.keys(allTestParams)
        .filter(k => k !== 'input_variables' && typeof allTestParams[k] === 'object' && allTestParams[k] !== null);
    const simpleTestParams = Object.keys(allTestParams)
        .filter(k => k !== 'input_variables' && (typeof allTestParams[k] !== 'object' || allTestParams[k] === null));


    return (
        <div className="flex flex-col h-screen bg-slate-50 text-slate-900 font-sans relative">
            <DeleteModal deleteTarget={deleteTarget} setDeleteTarget={setDeleteTarget} confirmDelete={confirmDelete} />
            <Header
                isYamlLoaded={isYamlLoaded}
                handleFileUpload={handleFileUpload}
                handleDownload={handleDownload}
                initiateRun={initiateRun}
            />
            <div className="flex flex-1 overflow-hidden">
                <Sidebar
                    data={data}
                    setData={setData as (data: YamlData) => void}
                    activeChatIndex={activeChatIndex}
                    setActiveChatIndex={setActiveChatIndex}
                    setActiveRefKey={setActiveRefKey}
                />
                <main className="flex-1 flex flex-col bg-slate-50 overflow-hidden">
                    <div className="bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between">
                        <div className="flex gap-4">
                            {['flow', 'params', 'references', 'settings'].map(t => (
                                <button key={t} onClick={() => setActiveTab(t)} className={`text-sm font-medium pb-1 border-b-2 capitalize transition-colors ${activeTab === t ? 'border-blue-500 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>{t}</button>
                            ))}
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="text-xs text-slate-500">Scenario Title:</span>
                            <input value={activeChat.title} onChange={(e) => updateChat(activeChatIndex, 'title', e.target.value)} className="text-sm px-2 py-1 border border-slate-300 rounded focus:border-blue-500 outline-none w-48" />
                        </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-8">
                        <div className="max-w-4xl mx-auto">
                            {activeTab === 'flow' && (
                                <FlowTab
                                    activeChat={activeChat}
                                    addMessageStep={addMessageStep}
                                    updateMessageStep={updateMessageStep}
                                    deleteMessageStep={deleteMessageStep}
                                    moveMessageStep={moveMessageStep}
                                    simpleTestParams={simpleTestParams}
                                    availableRefs={availableRefs}
                                    insertParam={insertParam}
                                    toggleParameterized={toggleParameterized}
                                />
                            )}
                            {activeTab === 'params' && (
                                <ParamsTab
                                    activeChat={activeChat}
                                    updateInputVariable={updateInputVariable}
                                    updateTestParameter={updateTestParameter}
                                    requestDelete={requestDelete}
                                    simpleTestParams={simpleTestParams}
                                    inputVars={inputVars}
                                    allTestParams={allTestParams}
                                    confirmCreateVariable={confirmCreateVariable}
                                    confirmCreateTestParam={confirmCreateTestParam}
                                />
                            )}
                            {activeTab === 'references' && (
                                <ReferencesTab
                                    activeChat={activeChat}
                                    activeRefKey={activeRefKey}
                                    setActiveRefKey={setActiveRefKey}
                                    availableRefs={availableRefs}
                                    allTestParams={allTestParams}
                                    requestDelete={requestDelete}
                                    confirmCreateReference={confirmCreateReference}
                                    addRefMessageStep={addRefMessageStep}
                                    updateRefMessageStep={updateRefMessageStep}
                                    deleteRefMessageStep={deleteRefMessageStep}
                                />
                            )}
                            {activeTab === 'settings' && (
                                <SettingsTab
                                    activeChat={activeChat}
                                    updateChat={updateChat}
                                    activeChatIndex={activeChatIndex}
                                />
                            )}
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
};
