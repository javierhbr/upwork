
import React from 'react';
import { Loader2, Clock } from 'lucide-react';
import { RunConfig } from '../types';

interface RunningViewProps {
    runConfig: RunConfig;
    runTimer: number;
}

export const RunningView: React.FC<RunningViewProps> = ({ runConfig, runTimer }) => {
    return (
        <div className="flex flex-col h-screen bg-slate-50 items-center justify-center relative">
            <div className="bg-white p-10 rounded-2xl shadow-xl flex flex-col items-center max-w-sm w-full">
                <div className="relative mb-6">
                    <div className="absolute inset-0 bg-blue-100 rounded-full animate-ping opacity-20"></div>
                    <Loader2 className="w-16 h-16 text-blue-600 animate-spin relative z-10" />
                </div>

                <h2 className="text-xl font-bold text-slate-800 mb-2">Running Test...</h2>
                <p className="text-slate-500 text-sm mb-6 text-center">
                    Executing scenario against OCP Group: <br />
                    <span className="font-mono font-medium text-slate-700">{runConfig.ocpGroup}</span>
                </p>

                <div className="flex items-center gap-2 px-4 py-2 bg-slate-100 rounded-full font-mono text-slate-600">
                    <Clock className="w-4 h-4" />
                    <span>{(runTimer / 1000).toFixed(1)}s</span>
                </div>
            </div>
        </div>
    );
};
