
import React from 'react';
import { Chat } from '../types';

interface SettingsTabProps {
    activeChat: Chat;
    updateChat: (index: number, field: keyof Chat, value: any) => void;
    activeChatIndex: number;
}

export const SettingsTab: React.FC<SettingsTabProps> = ({ activeChat, updateChat, activeChatIndex }) => {
    return (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="font-semibold mb-4">General Configuration</h3>
            <div className="grid grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-medium mb-1">Timeout (s)</label>
                    <input type="number" value={activeChat.timeout} onChange={(e) => updateChat(activeChatIndex, 'timeout', e.target.value)} className="w-full p-2 border rounded" />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Labels</label>
                    <input value={(activeChat.labels || []).join(', ')} onChange={(e) => updateChat(activeChatIndex, 'labels', e.target.value.split(','))} className="w-full p-2 border rounded" />
                </div>
            </div>
        </div>
    );
};
