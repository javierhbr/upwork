
import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { YamlData, Chat } from '../types';

interface SidebarProps {
    data: YamlData;
    setData: (data: YamlData) => void;
    activeChatIndex: number;
    setActiveChatIndex: (index: number) => void;
    setActiveRefKey: (key: string | null) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ data, setData, activeChatIndex, setActiveChatIndex, setActiveRefKey }) => {
    const addChat = () => {
        const newData = { ...data };
        newData.chats.push({ title: "new-scenario", timeout: 30, labels: [], expectedMessages: [] });
        setData(newData);
        setActiveChatIndex(newData.chats.length - 1);
    };

    const deleteChat = (e: React.MouseEvent, index: number) => {
        e.stopPropagation();
        if (confirm('Delete this scenario?')) {
            const newData = { ...data };
            newData.chats.splice(index, 1);
            setData(newData);
            setActiveChatIndex(0);
        }
    };

    return (
        <aside className="w-64 bg-white border-r border-slate-200 flex flex-col">
            <div className="p-4 border-b border-slate-100">
                <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Test Scenarios</h2>
                <input
                    value={data.name || ''}
                    onChange={(e) => setData({ ...data, name: e.target.value })}
                    className="w-full text-sm p-2 border border-slate-300 rounded mb-2"
                    placeholder="Suite Name"
                />
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-1">
                {data.chats.map((chat, idx) => (
                    <button
                        key={idx}
                        onClick={() => { setActiveChatIndex(idx); setActiveRefKey(null); }}
                        className={`w-full text-left p-3 rounded-md text-sm flex items-center justify-between group ${idx === activeChatIndex ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'text-slate-600 hover:bg-slate-50'}`}
                    >
                        <span className="truncate font-medium">{chat.title || 'Untitled Chat'}</span>
                        {data.chats.length > 1 && (
                            <Trash2
                                className="w-4 h-4 opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500"
                                onClick={(e) => deleteChat(e, idx)}
                            />
                        )}
                    </button>
                ))}
                <button
                    onClick={addChat}
                    className="w-full mt-2 py-2 border border-dashed border-slate-300 text-slate-500 rounded-md text-sm hover:border-blue-400 hover:text-blue-600 flex items-center justify-center gap-2"
                >
                    <Plus className="w-3 h-3" /> New Scenario
                </button>
            </div>
        </aside>
    );
};
