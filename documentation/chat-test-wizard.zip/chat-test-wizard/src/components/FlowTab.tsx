
import React from 'react';
import { Bot, User, FileJson, ChevronUp, ChevronDown, Trash2 } from 'lucide-react';
import { MessageStep, Chat } from '../types';

interface FlowTabProps {
    activeChat: Chat;
    addMessageStep: (type: 'bot' | 'user' | 'reference') => void;
    updateMessageStep: (msgIndex: number, key: string, val: string) => void;
    deleteMessageStep: (msgIndex: number) => void;
    moveMessageStep: (msgIndex: number, direction: -1 | 1) => void;
    simpleTestParams: string[];
    availableRefs: string[];
    insertParam: (msgIndex: number, field: string, paramName: string) => void;
    toggleParameterized: (msgIndex: number) => void;
}

export const FlowTab: React.FC<FlowTabProps> = ({
    activeChat,
    addMessageStep,
    updateMessageStep,
    deleteMessageStep,
    moveMessageStep,
    simpleTestParams,
    availableRefs,
    insertParam,
    toggleParameterized,
}) => {
    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-slate-800">Interaction Script</h3>
                <div className="flex gap-2 text-xs">
                    <div className="flex items-center gap-1"><div className="w-3 h-3 bg-blue-100 border border-blue-300 rounded-full"></div> Bot</div>
                    <div className="flex items-center gap-1"><div className="w-3 h-3 bg-green-100 border border-green-300 rounded-full"></div> User</div>
                </div>
            </div>
            <div className="space-y-3 pb-20">
                {(activeChat.expectedMessages || []).map((msg, idx) => {
                    const isBot = msg.hasOwnProperty('bot');
                    const isUser = msg.hasOwnProperty('user');
                    const isRef = msg.hasOwnProperty('reference');
                    return (
                        <div key={idx} className="group flex gap-4 items-start animate-in fade-in slide-in-from-bottom-2 duration-300">
                            <div className="w-8 flex flex-col items-center opacity-0 group-hover:opacity-100 transition-opacity pt-2">
                                <button onClick={() => moveMessageStep(idx, -1)} className="p-1 hover:text-blue-600"><ChevronUp className="w-3 h-3" /></button>
                                <button onClick={() => deleteMessageStep(idx)} className="p-1 hover:text-red-600"><Trash2 className="w-3 h-3" /></button>
                                <button onClick={() => moveMessageStep(idx, 1)} className="p-1 hover:text-blue-600"><ChevronDown className="w-3 h-3" /></button>
                            </div>
                            <div className={`flex-1 flex ${isUser ? 'justify-end' : 'justify-start'}`}>
                                <div className={`relative max-w-2xl w-full p-4 rounded-xl border shadow-sm flex flex-col gap-2 ${isBot ? 'bg-white border-slate-200 rounded-tl-none' : ''} ${isUser ? 'bg-green-50 border-green-100 rounded-tr-none' : ''} ${isRef ? 'bg-slate-100 border-dashed border-slate-300' : ''}`}>
                                    <div className="flex gap-3">
                                        <div className={`mt-1 flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${isBot ? 'bg-blue-100 text-blue-600' : ''} ${isUser ? 'bg-green-200 text-green-700' : ''} ${isRef ? 'bg-slate-300 text-slate-600' : ''}`}>
                                            {isBot && <Bot className="w-5 h-5" />}
                                            {isUser && <User className="w-5 h-5" />}
                                            {isRef && <FileJson className="w-5 h-5" />}
                                        </div>
                                        <div className="flex-1 relative">
                                            <div className="flex justify-between items-center mb-1">
                                                <label className="text-xs font-bold uppercase tracking-wider opacity-50 block">{isBot ? 'Bot Expectation' : isUser ? 'User Input / Action' : 'Load Reference'}</label>
                                                {!isRef && simpleTestParams.length > 0 && (
                                                    <div className="relative">
                                                        <select className="text-[10px] border border-slate-200 rounded bg-slate-50 text-slate-600 px-1 py-0.5 outline-none hover:border-blue-300 cursor-pointer w-24" onChange={(e) => { if (e.target.value) { insertParam(idx, isBot ? 'bot' : 'user', e.target.value); e.target.value = ""; } }} defaultValue="">
                                                            <option value="" disabled>Insert Var...</option>
                                                            {simpleTestParams.map(p => <option key={p} value={p}>{p}</option>)}
                                                        </select>
                                                    </div>
                                                )}
                                            </div>
                                            {isRef ? (
                                                <select className="w-full bg-transparent border-b border-slate-400 focus:border-blue-500 outline-none py-1 text-slate-700 font-mono cursor-pointer" value={msg.reference} onChange={(e) => updateMessageStep(idx, 'reference', e.target.value)}>
                                                    <option value="" disabled>Select a reference...</option>
                                                    {availableRefs.map(ref => <option key={ref} value={ref}>{ref}</option>)}
                                                </select>
                                            ) : (
                                                <textarea className="w-full bg-transparent resize-none outline-none text-slate-800" rows={isUser ? 1 : 2} value={isBot ? msg.bot : msg.user} placeholder={isBot ? "What should the bot say?" : "What does the user say/press?"} onChange={(e) => updateMessageStep(idx, isBot ? 'bot' : 'user', e.target.value)} />
                                            )}
                                        </div>
                                    </div>
                                    {isUser && msg.user && msg.user.includes('$') && (
                                        <div className="border-t border-green-200 mt-2 pt-2 flex items-center gap-2">
                                            <input type="checkbox" id={`param-${idx}`} checked={!!msg.parameterized} onChange={() => toggleParameterized(idx)} className="w-3 h-3 text-blue-600 rounded" />
                                            <label htmlFor={`param-${idx}`} className="text-xs text-slate-600 cursor-pointer select-none">Use as Parameter ({msg.parameterized ? 'True' : 'False'})</label>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    );
                })}
                <div className="flex justify-center gap-4 mt-8 pt-4 border-t border-slate-200">
                    <button onClick={() => addMessageStep('bot')} className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 shadow-sm rounded-full text-slate-700 hover:bg-blue-50 hover:border-blue-200 hover:text-blue-700 transition-all"><Bot className="w-4 h-4" /> Add Bot Step</button>
                    <button onClick={() => addMessageStep('user')} className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 shadow-sm rounded-full text-slate-700 hover:bg-green-50 hover:border-green-200 hover:text-green-700 transition-all"><User className="w-4 h-4" /> Add User Step</button>
                    <button onClick={() => addMessageStep('reference')} className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 shadow-sm rounded-full text-slate-700 hover:bg-slate-100 transition-all"><FileJson className="w-4 h-4" /> Add Reference</button>
                </div>
            </div>
        </div>
    );
};
