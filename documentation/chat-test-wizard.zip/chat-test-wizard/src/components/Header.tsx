
import React from 'react';
import { Upload, Download, Settings, Play } from 'lucide-react';

interface HeaderProps {
    isYamlLoaded: boolean;
    handleFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
    handleDownload: () => void;
    initiateRun: () => void;
}

export const Header: React.FC<HeaderProps> = ({ isYamlLoaded, handleFileUpload, handleDownload, initiateRun }) => {
    return (
        <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between shadow-sm sticky top-0 z-10">
            <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-600 rounded-lg"><Settings className="w-5 h-5 text-white" /></div>
                <div>
                    <h1 className="text-xl font-bold text-slate-800">IVR Scenario Builder</h1>
                    <p className="text-xs text-slate-500">Edit YAML configurations visually</p>
                </div>
            </div>
            <div className="flex items-center gap-3">
                <button
                    onClick={initiateRun}
                    className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md transition-colors text-sm font-medium shadow-sm"
                >
                    <Play className="w-4 h-4 fill-current" />
                    Run Scenario
                </button>
                <div className="h-6 w-px bg-slate-200 mx-2"></div>
                <label className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md cursor-pointer transition-colors text-sm font-medium">
                    <Upload className="w-4 h-4" /> Import
                    <input type="file" accept=".yaml,.yml" onChange={handleFileUpload} className="hidden" />
                </label>
                <button onClick={handleDownload} disabled={!isYamlLoaded} className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition-colors text-sm font-medium shadow-sm disabled:opacity-50">
                    <Download className="w-4 h-4" /> Export
                </button>
            </div>
        </header>
    );
};
