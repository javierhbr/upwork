
import React, { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Chat } from '../types';

interface ParamsTabProps {
    activeChat: Chat;
    updateInputVariable: (key: string, value: string) => void;
    updateTestParameter: (key: string, value: string) => void;
    requestDelete: (type: string, key: string, e?: React.MouseEvent) => void;
    simpleTestParams: string[];
    inputVars: { [key: string]: string };
    allTestParams: { [key: string]: any };
    confirmCreateVariable: (key: string) => void;
    confirmCreateTestParam: (key: string) => void;
}

export const ParamsTab: React.FC<ParamsTabProps> = ({
    activeChat,
    updateInputVariable,
    updateTestParameter,
    requestDelete,
    simpleTestParams,
    inputVars,
    allTestParams,
    confirmCreateVariable,
    confirmCreateTestParam,
}) => {
    const [isCreatingVar, setIsCreatingVar] = useState(false);
    const [newVarName, setNewVarName] = useState("");
    const [isCreatingTestParam, setIsCreatingTestParam] = useState(false);
    const [newTestParamName, setNewTestParamName] = useState("");

    const handleConfirmCreateVariable = () => {
        if (!newVarName.trim()) {
            setIsCreatingVar(false);
            return;
        }
        confirmCreateVariable(newVarName);
        setNewVarName("");
        setIsCreatingVar(false);
    };

    const handleConfirmCreateTestParam = () => {
        if (!newTestParamName.trim()) {
            setIsCreatingTestParam(false);
            return;
        }
        confirmCreateTestParam(newTestParamName);
        setNewTestParamName("");
        setIsCreatingTestParam(false);
    };


    return (
        <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold text-slate-800">Test Input Variables</h3>
                    <button onClick={() => setIsCreatingVar(true)} className="text-sm text-blue-600"><Plus className="w-4 h-4 inline" /> Add</button>
                </div>
                {isCreatingVar && <input autoFocus className="w-full mb-2 p-2 text-sm border rounded" placeholder="Key..." value={newVarName} onChange={e => setNewVarName(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') handleConfirmCreateVariable() }} />}
                {Object.entries(inputVars).map(([k, v]) => (
                    <div key={k} className="flex items-center gap-4 mb-2">
                        <span className="w-1/3 font-mono text-sm text-slate-700">{k}</span>
                        <input className="flex-1 border-b bg-transparent" value={v} onChange={e => updateInputVariable(k, e.target.value)} />
                        <Trash2 className="w-4 h-4 text-slate-300 hover:text-red-500 cursor-pointer" onClick={(e) => requestDelete('variable', k, e)} />
                    </div>
                ))}
            </div>
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold text-slate-800">Test Parameters</h3>
                    <button onClick={() => setIsCreatingTestParam(true)} className="text-sm text-purple-600"><Plus className="w-4 h-4 inline" /> Add</button>
                </div>
                {isCreatingTestParam && <input autoFocus className="w-full mb-2 p-2 text-sm border rounded" placeholder="Key..." value={newTestParamName} onChange={e => setNewTestParamName(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') handleConfirmCreateTestParam() }} />}
                {simpleTestParams.map(k => (
                    <div key={k} className="flex items-center gap-4 mb-2">
                        <span className="w-1/3 font-mono text-sm text-slate-700">{k}</span>
                        <input className="flex-1 border-b bg-transparent" value={allTestParams[k]} onChange={e => updateTestParameter(k, e.target.value)} />
                        <Trash2 className="w-4 h-4 text-slate-300 hover:text-red-500 cursor-pointer" onClick={(e) => requestDelete('test_param', k, e)} />
                    </div>
                ))}
            </div>
        </div>
    );
};
