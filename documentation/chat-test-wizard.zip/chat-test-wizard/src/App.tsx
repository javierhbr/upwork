
import React from 'react';
import { useYamlData } from './hooks/useYamlData';
import { useChatState } from './hooks/useChatState';
import { useRunnerState } from './hooks/useRunnerState';
import { EditorView } from './components/EditorView';
import { RunConfigView } from './components/RunConfigView';
import { RunningView } from './components/RunningView';
import { ResultsView } from './components/ResultsView';
import { YamlData } from './types';

const App = () => {
    const { data, setData, isYamlLoaded, handleFileUpload, handleDownload } = useYamlData();
    const { activeChat } = useChatState(data, setData as (data: YamlData) => void);
    const {
        viewState,
        setViewState,
        runConfig,
        setRunConfig,
        runTimer,
        simulationResult,
        initiateRun,
        startSimulation,
        closeRunner,
    } = useRunnerState(activeChat);

    if (viewState === 'config') {
        return (
            <RunConfigView
                runConfig={runConfig}
                setRunConfig={setRunConfig}
                setViewState={setViewState}
                startSimulation={startSimulation}
                labels={activeChat.labels || []}
            />
        );
    }

    if (viewState === 'running') {
        return <RunningView runConfig={runConfig} runTimer={runTimer} />;
    }

    if (viewState === 'results' && simulationResult) {
        return <ResultsView simulationResult={simulationResult} runConfig={runConfig} closeRunner={closeRunner} />;
    }

    return <EditorView />;
};

export default App;
