
import { useState, useEffect } from 'react';
import { YamlData, Chat } from '../types';

const INITIAL_YAML: YamlData = {
    name: "New_Card_Application",
    chats: [
      {
        title: "default-scenario",
        timeout: 45,
        labels: ["default"],
        input_variables: {
          Ani: "1234567890",
          Dnis: "+18005550199",
          envMode: "UAT"
        },
        test_parameters: {
          PIN: 1234,
          WELCOME_LANGUAGE: {
            messages: [
              { bot: "Thanks for calling Capital One." },
              { bot: "Para Espanol, oprima el 2" }
            ]
          }
        },
        ignoredMessages: [{ bot: "Please wait" }],
        expectedMessages: [
          { reference: "WELCOME_LANGUAGE" },
          { user: "1" }
        ]
      }
    ]
  };

const loadYamlLibrary = () => {
    return new Promise<any>((resolve, reject) => {
        if (window.jsyaml) {
            resolve(window.jsyaml);
            return;
        }
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/js-yaml/4.1.0/js-yaml.min.js';
        script.onload = () => resolve(window.jsyaml);
        script.onerror = () => reject(new Error('Failed to load YAML library'));
        document.head.appendChild(script);
    });
};

export const useYamlData = () => {
    const [data, setData] = useState<YamlData>(INITIAL_YAML);
    const [isYamlLoaded, setIsYamlLoaded] = useState(false);

    useEffect(() => {
        loadYamlLibrary().then(() => setIsYamlLoaded(true));
    }, []);

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const parsed = window.jsyaml.load(event.target?.result as string);
                setData(parsed);
            } catch (error) {
                alert("Error parsing YAML file. Please check the syntax.");
                console.error(error);
            }
        };
        reader.readAsText(file);
    };

    const handleDownload = () => {
        if (!window.jsyaml) return;
        const yamlStr = window.jsyaml.dump(data, { lineWidth: -1 });
        const blob = new Blob([yamlStr], { type: 'text/yaml' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${data.name || 'ivr-test'}.yaml`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return {
        data,
        setData,
        isYamlLoaded,
        handleFileUpload,
        handleDownload,
    };
};
