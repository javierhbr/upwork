
import { useState, useRef } from 'react';
import { Chat, RunConfig, SimulationResult } from '../types';

export const useRunnerState = (activeChat: Chat) => {
    const [viewState, setViewState] = useState<'editor' | 'config' | 'running' | 'results'>('editor');
    const [runConfig, setRunConfig] = useState<RunConfig>({ ocpGroup: '', label: '' });
    const [runTimer, setRunTimer] = useState(0);
    const [simulationResult, setSimulationResult] = useState<SimulationResult | null>(null);
    const timerRef = useRef<NodeJS.Timeout | null>(null);

    const getInputVariables = (chat: Chat) => {
        if (chat.input_variables) return chat.input_variables;
        if (chat.test_parameters && chat.test_parameters.input_variables) return chat.test_parameters.input_variables as { [key: string]: string};
        return {};
    };

    const initiateRun = () => {
        const defaultLabel = activeChat.labels && activeChat.labels.length > 0 ? activeChat.labels[0] : '';
        setRunConfig({ ocpGroup: '', label: defaultLabel });
        setViewState('config');
    };

    const startSimulation = () => {
        setViewState('running');
        setRunTimer(0);

        timerRef.current = setInterval(() => {
            setRunTimer(prev => prev + 100);
        }, 100);

        setTimeout(() => {
            finishSimulation();
        }, 2500);
    };

    const finishSimulation = () => {
        if(timerRef.current) clearInterval(timerRef.current);

        const mockMessages: { time: number; source: string; message: string }[] = [];
        let currentTime = 300;

        const addMsg = (src: string, txt: string) => {
            mockMessages.push({
                time: currentTime,
                source: src,
                message: txt
            });
            currentTime += Math.floor(Math.random() * 800) + 200;
        };

        (activeChat.expectedMessages || []).forEach(step => {
            if (step.bot) addMsg('BOT', step.bot);
            if (step.user) addMsg('USER', step.user);
            if (step.reference) addMsg('REF', `[Executed Reference: ${step.reference}]`);
        });

        setSimulationResult({
            dialogId: `4c${Math.random().toString(16).substr(2, 10)}...`,
            startTime: new Date().toISOString(),
            inputVariables: getInputVariables(activeChat),
            messages: mockMessages,
            chatTitle: activeChat.title
        });

        setViewState('results');
    };

    const closeRunner = () => {
        setViewState('editor');
        setSimulationResult(null);
    };

    return {
        viewState,
        setViewState,
        runConfig,
        setRunConfig,
        runTimer,
        simulationResult,
        initiateRun,
        startSimulation,
        closeRunner,
    };
};
