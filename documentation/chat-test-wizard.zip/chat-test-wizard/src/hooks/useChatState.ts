
import { useState } from 'react';
import { YamlData, Chat, MessageStep } from '../types';

export const useChatState = (data: YamlData, setData: (data: YamlData) => void) => {
    const [activeChatIndex, setActiveChatIndex] = useState(0);
    const [activeRefKey, setActiveRefKey] = useState<string | null>(null);
    const [deleteTarget, setDeleteTarget] = useState<{ type: string; key: string } | null>(null);

    const activeChat = data.chats[activeChatIndex];

    const updateChat = (index: number, field: keyof Chat, value: any) => {
        const newData = { ...data };
        newData.chats[index] = { ...newData.chats[index], [field]: value };
        setData(newData);
    };

    const addMessageStep = (type: 'bot' | 'user' | 'reference') => {
        const newData = { ...data };
        const messages = newData.chats[activeChatIndex].expectedMessages || [];
        let newStep: MessageStep = {};
        if (type === 'bot') newStep = { bot: "" };
        if (type === 'user') newStep = { user: "" };
        if (type === 'reference') newStep = { reference: "" };
        newData.chats[activeChatIndex].expectedMessages = [...messages, newStep];
        setData(newData);
    };

    const updateMessageStep = (msgIndex: number, key: string, val: string) => {
        const newData = { ...data };
        newData.chats[activeChatIndex].expectedMessages[msgIndex] = {
            ...newData.chats[activeChatIndex].expectedMessages[msgIndex],
            [key]: val
        };
        setData(newData);
    };

    const deleteMessageStep = (msgIndex: number) => {
        const newData = { ...data };
        newData.chats[activeChatIndex].expectedMessages.splice(msgIndex, 1);
        setData(newData);
    };

    const moveMessageStep = (msgIndex: number, direction: -1 | 1) => {
        const newData = { ...data };
        const messages = newData.chats[activeChatIndex].expectedMessages;
        if (direction === -1 && msgIndex > 0) {
            [messages[msgIndex], messages[msgIndex - 1]] = [messages[msgIndex - 1], messages[msgIndex]];
        } else if (direction === 1 && msgIndex < messages.length - 1) {
            [messages[msgIndex], messages[msgIndex + 1]] = [messages[msgIndex + 1], messages[msgIndex]];
        }
        setData(newData);
    };

    const requestDelete = (type: string, key: string, e?: React.MouseEvent) => {
        if (e) e.stopPropagation();
        setDeleteTarget({ type, key });
    };

    const confirmDelete = () => {
        if (!deleteTarget) return;
        const newData = { ...data };
        const chat = newData.chats[activeChatIndex];
        if (deleteTarget.type === 'reference' || deleteTarget.type === 'test_param') {
            if (chat.test_parameters) delete chat.test_parameters[deleteTarget.key];
            if (activeRefKey === deleteTarget.key) setActiveRefKey(null);
        } else if (deleteTarget.type === 'variable') {
            if (chat.test_parameters?.input_variables) delete (chat.test_parameters.input_variables as any)[deleteTarget.key];
            else if (chat.input_variables) delete chat.input_variables[deleteTarget.key];
        }
        setData(newData);
        setDeleteTarget(null);
    };

    const getInputVariables = (chat: Chat) => {
        if (chat.input_variables) return chat.input_variables;
        if (chat.test_parameters && chat.test_parameters.input_variables) return chat.test_parameters.input_variables as { [key: string]: string};
        return {};
      };

    const confirmCreateVariable = (key: string) => {
        const newData = { ...data };
        const chat = newData.chats[activeChatIndex];
        const existingVars = getInputVariables(chat);
        if (existingVars.hasOwnProperty(key)) { alert("Exists."); return; }
        if (chat.test_parameters && chat.test_parameters.input_variables) (chat.test_parameters.input_variables as any)[key] = "";
        else { if (!chat.input_variables) chat.input_variables = {}; chat.input_variables[key] = ""; }
        setData(newData);
    };
    
    const confirmCreateTestParam = (key: string) => {
        const newData = { ...data };
        const chat = newData.chats[activeChatIndex];
        if (!chat.test_parameters) chat.test_parameters = {};
        if (chat.test_parameters.hasOwnProperty(key)) { alert("Exists."); return; }
        chat.test_parameters[key] = "";
        setData(newData);
    };

    const confirmCreateReference = (key: string) => {
        const newData = { ...data };
        const chat = newData.chats[activeChatIndex];
        if (!chat.test_parameters) chat.test_parameters = {};
        if (key === 'input_variables' || chat.test_parameters[key]) { alert("Invalid/duplicate name."); return; }
        chat.test_parameters[key] = { messages: [] };
        setData(newData);
        setActiveRefKey(key);
    };

    const addRefMessageStep = (type: 'bot' | 'user') => {
        if (!activeRefKey) return;
        const newData = { ...data };
        const ref = newData.chats[activeChatIndex].test_parameters?.[activeRefKey] as any;
        if (!ref.messages) ref.messages = [];
        ref.messages.push(type === 'bot' ? { bot: "" } : { user: "" });
        setData(newData);
    };

    const updateRefMessageStep = (msgIndex: number, key: string, val: string) => {
        if (!activeRefKey) return;
        const newData = { ...data };
        (newData.chats[activeChatIndex].test_parameters as any)[activeRefKey].messages[msgIndex] = { [key]: val };
        setData(newData);
    };

    const deleteRefMessageStep = (msgIndex: number) => {
        if (!activeRefKey) return;
        const newData = { ...data };
        (newData.chats[activeChatIndex].test_parameters as any)[activeRefKey].messages.splice(msgIndex, 1);
        setData(newData);
    };

    const updateInputVariable = (key: string, value: string) => {
        const newData = { ...data };
        const chat = newData.chats[activeChatIndex];
        if (chat.test_parameters && chat.test_parameters.input_variables) {
            (chat.test_parameters.input_variables as any)[key] = value;
        } else {
            if (!chat.input_variables) chat.input_variables = {};
            chat.input_variables[key] = value;
        }
        setData(newData);
    };
    
    const updateTestParameter = (key: string, value: string) => {
        const newData = { ...data };
        const chat = newData.chats[activeChatIndex];
        if (!chat.test_parameters) chat.test_parameters = {};
        chat.test_parameters[key] = value;
        setData(newData);
    };

    const insertParam = (msgIndex: number, field: string, paramName: string) => {
        const newData = { ...data };
        const currentVal = (newData.chats[activeChatIndex].expectedMessages[msgIndex] as any)[field] || "";
        const token = `${paramName}`;
        const newVal = currentVal ? `${currentVal} ${token}` : token;
        (newData.chats[activeChatIndex].expectedMessages[msgIndex] as any)[field] = newVal;
        if (field === 'user') {
            newData.chats[activeChatIndex].expectedMessages[msgIndex].parameterized = true;
        }
        setData(newData);
    };

    const toggleParameterized = (msgIndex: number) => {
        const newData = { ...data };
        const msg = newData.chats[activeChatIndex].expectedMessages[msgIndex];
        if (msg.parameterized) {
            delete msg.parameterized;
        } else {
            msg.parameterized = true;
        }
        setData(newData);
    };

    return {
        activeChatIndex,
        setActiveChatIndex,
        activeRefKey,
        setActiveRefKey,
        activeChat,
        updateChat,
        addMessageStep,
        updateMessageStep,
        deleteMessageStep,
        moveMessageStep,
        deleteTarget,
        requestDelete,
        confirmDelete,
        confirmCreateVariable,
        confirmCreateTestParam,
        confirmCreateReference,
        addRefMessageStep,
        updateRefMessageStep,
        deleteRefMessageStep,
        updateInputVariable,
        updateTestParameter,
        insertParam,
        toggleParameterized,
        setDeleteTarget,
    };
};
