
export interface MessageStep {
  bot?: string;
  user?: string;
  reference?: string;
  parameterized?: boolean;
}

export interface ReferenceMessages {
  messages: MessageStep[];
}

export interface TestParameters {
  [key: string]: string | number | ReferenceMessages;
}

export interface Chat {
  title: string;
  timeout: number;
  labels: string[];
  input_variables?: { [key: string]: string };
  test_parameters?: TestParameters;
  ignoredMessages?: { bot: string }[];
  expectedMessages: MessageStep[];
}

export interface YamlData {
  name: string;
  chats: Chat[];
}

export interface RunConfig {
  ocpGroup: string;
  label: string;
}

export interface SimulationResult {
  dialogId: string;
  startTime: string;
  inputVariables: { [key: string]: string };
  messages: { time: number; source: string; message: string }[];
  chatTitle: string;
}

declare global {
  interface Window {
    jsyaml: any;
  }
}
