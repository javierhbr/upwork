
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      // The slate, blue, green, and red colors used in the app 
      // are included in Tailwind's default theme, so no 
      // specific color overrides are needed here.
    },
  },
  plugins: [
    // This plugin is required for the 'animate-in', 'fade-in', 
    // and 'slide-in' classes used in the modal and chat bubbles.
    require("tailwindcss-animate"), 
  ],
}